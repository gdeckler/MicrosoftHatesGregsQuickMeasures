﻿using System;
using System.ComponentModel;
using System.Security.Permissions;
using System.IO;

namespace PBIExternalTool
{
    [RunInstaller(true)]
    public partial class Installer1 : System.Configuration.Install.Installer
    {
        public Installer1()
        {
            InitializeComponent();
        }

        [SecurityPermission(SecurityAction.Demand)]
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);

            string exeName = Context.Parameters["assemblypath"];
            string appDir = Path.GetDirectoryName(exeName);
            string pbiDir = Environment.ExpandEnvironmentVariables(@"%CommonProgramFiles%\microsoft shared\Power BI Desktop");
            string extDir = Environment.ExpandEnvironmentVariables(@"%CommonProgramFiles%\microsoft shared\Power BI Desktop\External Tools");
            string pbiSharedDir = Environment.ExpandEnvironmentVariables(@"%CommonProgramFiles%\microsoft shared\Power BI Desktop\External Tools\");
            string pbiToolsJsonTemplate = $"{appDir}\\PBIExternalTool.pbitool.json";
            if (!Directory.Exists(pbiDir))
            {
                Directory.CreateDirectory(pbiDir);
            }
            if (!Directory.Exists(extDir))
            {
                Directory.CreateDirectory(extDir);
            }
            if (File.Exists(pbiToolsJsonTemplate))
            {
                string pbiToolsJson = File.ReadAllText(pbiToolsJsonTemplate).Replace("<PBIEXTERNALTOOL_PATH>", exeName.Replace("\\", "\\\\"));
                File.WriteAllText($"{pbiSharedDir}\\PBIExternalTool.pbitool.json", pbiToolsJson);
            }
        }

        [SecurityPermission(SecurityAction.Demand)]
        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            base.Uninstall(savedState);

            string pbiSharedDir = Environment.ExpandEnvironmentVariables(@"%CommonProgramFiles%\microsoft shared\Power BI Desktop\External Tools\");
            string pbiToolFile = $"{pbiSharedDir}\\PBIExternalTool.pbitool.json";
            if (File.Exists(pbiToolFile))
            {
                File.Delete(pbiToolFile);
            }
        }
    }
}
