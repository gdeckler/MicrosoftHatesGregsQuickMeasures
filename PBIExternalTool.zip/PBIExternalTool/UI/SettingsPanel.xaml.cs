﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Diagnostics;
using System.Windows.Forms;

namespace PBIExternalTool
{
    /// <summary>
    /// Interaction logic for SettingsPanel.xaml
    /// </summary>
    public partial class SettingsPanel : System.Windows.Controls.UserControl
    {
        public SettingsPanel()
        {
            InitializeComponent();
        }
        private void Hyperlink_RequestNavigate1(object sender, RequestNavigateEventArgs e)
        {
            // for .NET Core you need to add UseShellExecute = true
            // see https://docs.microsoft.com/dotnet/api/system.diagnostics.processstartinfo.useshellexecute#property-value
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.github.com/gdeckler/MicrosoftHatesGregsQuickMeasures");
        }
        private void YouTube_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/channel/UCwBe41Y8QmLlL5S-_8XVabw");
        }

        private void BRButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.buckeyeranch.org/makeaninvestment.html");
        }
        private void HHButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.huckhouse.org/donate/");
        }
        private void COButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.celebratingone.org/donate");
        }
        private void PButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.patreon.com/Gregdeckler");
        }
        private void GFMButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.gofundme.com/f/microsoft-hates-gregs-quick-measures");
        }
        private void CAMPLPUGButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://community.powerbi.com/t5/Columbus-Azure-ML-and-Power-BI/gh-p/pbi_columbus_usergroup");
        }
    }
}
