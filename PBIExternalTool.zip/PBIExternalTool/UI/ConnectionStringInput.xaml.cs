﻿using System.Windows;
using System.Windows.Controls;


namespace PBIExternalTool
{
    /// <summary>
    /// Interaction logic for ConnectionStringInput.xaml
    /// </summary>
    public partial class ConnectionStringInput : UserControl
    {
        public ConnectionStringInput()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWnd = MainWindow.GetMainWindow(this);
            if (mainWnd != null)
            {
                mainWnd.ConnectToDataset(ConnectionString.Text);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
