﻿using System;
using System.Windows;
using System.Windows.Media;
using System.ComponentModel;

namespace PBIExternalTool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow(StartupEventArgs e) : this()
        {
            if (e.Args.Length == 2)
            {
                ConnectToDataset(e.Args[0], e.Args[1]);
            }
        }

        public MainWindow(string server, string database) : this()
        {
            ConnectToDataset(server, database);
        }

        /// <summary>
        /// Connects to the dataset using a connection string.
        /// </summary>
        /// <param name="connectionString"></param>
        public void ConnectToDataset(string connectionString)
        {
            try
            {
                DataModel = DataModel.Connect(connectionString);
                InitUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Connects to the dataset via server and database name.
        /// </summary>
        /// <param name="server"></param>
        /// <param name="database"></param>
        public void ConnectToDataset(string server, string database)
        {
            try
            {
                DataModel = DataModel.Connect(server, database);
                InitUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Current.Shutdown();
            }
        }

        #region Helper Functions
        private void InitUI()
        {
            PowerBIEngine = DataModel.ServerName;
            DatabaseName = DataModel.DatabaseName;
            this.Ads.AsServerInfo.Text = $"Data Source={PowerBIEngine};Initial Catalog={DatabaseName}";
        }

        /// <summary>
        /// Get a handle to the main window object so that other user controls can
        /// access the public properties of the main window object directly.
        /// </summary>
        /// <param name="child"></param>
        /// <returns></returns>
        public static MainWindow GetMainWindow(DependencyObject child)
        {
            if (child == null) return null;

            DependencyObject parentObject = VisualTreeHelper.GetParent(child);
            if (parentObject is MainWindow parent)
            {
                return parent;
            }
            else
            {
                return GetMainWindow(parentObject);
            }
        }
        #endregion

        #region Dependency Properties
        /// <summary>
        /// DataModel object
        /// </summary>
        public static readonly DependencyProperty DataModelProperty =
            DependencyProperty.Register("DataModel", typeof(DataModel), typeof(MainWindow));

        public DataModel DataModel
        {
            get { return (DataModel)GetValue(DataModelProperty); }
            set { SetValue(DataModelProperty, value); }
        }

        /// <summary>
        /// PowerBIEngine Property
        /// </summary>
        public static readonly DependencyProperty PowerBIEngineProperty =
            DependencyProperty.Register("PowerBIEngine", typeof(string), typeof(MainWindow));
        public string PowerBIEngine
        {
            set { SetValue(PowerBIEngineProperty, value); }
            get { return (string)GetValue(PowerBIEngineProperty); }
        }

        /// <summary>
        /// DatabaseName Property
        /// </summary>
        public static readonly DependencyProperty DatabaseNameProperty =
            DependencyProperty.Register("DatabaseName", typeof(string), typeof(MainWindow));
        public string DatabaseName
        {
            set { SetValue(DatabaseNameProperty, value); }
            get { return (string)GetValue(DatabaseNameProperty); }
        }
        #endregion

        #region Event Handlers
        /// <summary>
        /// Saves modified user settings.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnMainWindow_Closing(object sender, CancelEventArgs e)
        {
            Properties.Settings.Default.Save();
        }
        #endregion
    }
}
