# Ticket Iceberg Dashboard

A local web dashboard that queries `lakekeeper.analytics.tickets` through Trino and renders live ticket KPIs, filters, charts, and a privacy-conscious detail table.

## Prerequisites

- Node.js 18 or newer
- The Lakekeeper Docker environment running
- Trino exposed at `http://localhost:9999`
- A Trino Iceberg catalog named `lakekeeper`

## Start

From this folder:

```powershell
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000).

## Configuration

The defaults match the local environment built in this walkthrough. Override them as environment variables when needed:

```powershell
$env:TRINO_URL="http://localhost:9999"
$env:TRINO_USER="dashboard"
$env:TRINO_CATALOG="lakekeeper"
$env:TRINO_SCHEMA="analytics"
$env:TRINO_TABLE="tickets"
npm start
```

The browser never connects directly to Trino. The local Node server executes Trino statements and returns only the aggregated chart data and a detail view that excludes customer names, email addresses, descriptions, and resolutions.
