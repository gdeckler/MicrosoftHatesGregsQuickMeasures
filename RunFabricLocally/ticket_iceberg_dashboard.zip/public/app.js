const palette = ["#3dd6c6", "#4d8dff", "#ffbe5c", "#ff6f7d", "#a88bff", "#68d391", "#f78fb3", "#68b0ff"];
const charts = {};
Chart.defaults.color = "#8fa4ba";
Chart.defaults.borderColor = "rgba(143,164,186,.14)";
Chart.defaults.font.family = 'Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif';

function number(value, digits = 0) {
  if (value === null || value === undefined) return "—";
  return Number(value).toLocaleString(undefined, { maximumFractionDigits: digits });
}

function replaceChart(id, type, rows, options = {}) {
  if (charts[id]) charts[id].destroy();
  const labels = rows.map((row) => row.label ?? "Unknown");
  const values = rows.map((row) => Number(row.value));
  charts[id] = new Chart(document.getElementById(id), {
    type,
    data: { labels, datasets: [{ data: values, backgroundColor: type === "doughnut" ? palette : options.color || "#3dd6c6", borderWidth: type === "doughnut" ? 0 : 1, borderRadius: type === "bar" ? 6 : 0 }] },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: options.horizontal ? "y" : "x",
      plugins: { legend: { display: type === "doughnut", position: "bottom", labels: { usePointStyle: true, boxWidth: 8, padding: 14 } }, tooltip: { displayColors: false } },
      scales: type === "doughnut" ? {} : { x: { grid: { display: !options.horizontal } }, y: { beginAtZero: true, grid: { display: options.horizontal } } },
      cutout: type === "doughnut" ? "63%" : undefined
    }
  });
}

function setOptions(id, values) {
  const select = document.getElementById(id);
  values.forEach((value) => select.add(new Option(value, value)));
}

async function loadFilters() {
  const response = await fetch("/api/filters");
  if (!response.ok) throw new Error((await response.json()).error || "Could not load filter values");
  const filters = await response.json();
  setOptions("statusFilter", filters.statuses);
  setOptions("priorityFilter", filters.priorities);
  setOptions("channelFilter", filters.channels);
}

function renderTable(rows) {
  const tbody = document.getElementById("ticketRows");
  tbody.replaceChildren(...rows.map((row) => {
    const tr = document.createElement("tr");
    [row.ticket_id, row.product, row.ticket_type, row.status, row.priority, row.channel, row.satisfaction ?? "—"].forEach((value, index) => {
      const td = document.createElement("td");
      if ([3, 4].includes(index)) { const badge = document.createElement("span"); badge.className = "badge"; badge.textContent = value ?? "—"; td.append(badge); }
      else td.textContent = value ?? "—";
      tr.append(td);
    });
    return tr;
  }));
}

async function loadDashboard() {
  const button = document.getElementById("refreshButton");
  const errorPanel = document.getElementById("errorPanel");
  button.disabled = true;
  errorPanel.hidden = true;
  const params = new URLSearchParams({
    status: document.getElementById("statusFilter").value,
    priority: document.getElementById("priorityFilter").value,
    channel: document.getElementById("channelFilter").value
  });
  try {
    const response = await fetch(`/api/dashboard?${params}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Dashboard query failed");
    const kpi = data.kpis[0] || {};
    document.getElementById("totalTickets").textContent = number(kpi.total_tickets);
    document.getElementById("activeTickets").textContent = number(kpi.active_tickets);
    document.getElementById("avgSatisfaction").textContent = number(kpi.avg_satisfaction, 2);
    document.getElementById("avgResolution").textContent = number(kpi.avg_resolution_hours, 1);
    document.getElementById("sourceLabel").textContent = data.source;
    document.getElementById("connectionLabel").textContent = "Live connection";
    document.querySelector(".connection").className = "connection connected";
    document.getElementById("refreshTime").textContent = `Updated ${new Date(data.refreshedAt).toLocaleTimeString()}`;
    replaceChart("statusChart", "bar", data.status, { color: "#3dd6c6" });
    replaceChart("priorityChart", "doughnut", data.priority);
    replaceChart("channelChart", "doughnut", data.channel);
    replaceChart("productChart", "bar", data.product, { horizontal: true, color: "#4d8dff" });
    replaceChart("typeChart", "bar", data.type, { horizontal: true, color: "#a88bff" });
    replaceChart("satisfactionChart", "bar", data.satisfaction, { color: "#ffbe5c" });
    renderTable(data.detail);
  } catch (error) {
    errorPanel.hidden = false;
    document.getElementById("errorMessage").textContent = `${error.message}. Confirm Trino and the Lakekeeper Docker environment are running.`;
    document.getElementById("connectionLabel").textContent = "Connection failed";
    document.getElementById("sourceLabel").textContent = "Trino unavailable";
    document.querySelector(".connection").className = "connection failed";
  } finally { button.disabled = false; }
}

document.getElementById("refreshButton").addEventListener("click", loadDashboard);
["statusFilter", "priorityFilter", "channelFilter"].forEach((id) => document.getElementById(id).addEventListener("change", loadDashboard));

(async () => {
  try { await loadFilters(); } catch (error) { document.getElementById("errorPanel").hidden = false; document.getElementById("errorMessage").textContent = error.message; }
  await loadDashboard();
})();
