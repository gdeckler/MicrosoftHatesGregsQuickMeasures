import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const trinoUrl = (process.env.TRINO_URL || "http://localhost:9999").replace(/\/$/, "");
const trinoUser = process.env.TRINO_USER || "dashboard";
const catalog = process.env.TRINO_CATALOG || "lakekeeper";
const schema = process.env.TRINO_SCHEMA || "analytics";
const table = process.env.TRINO_TABLE || "tickets";

const qid = (value) => `"${String(value).replaceAll('"', '""')}"`;
const source = `${qid(catalog)}.${qid(schema)}.${qid(table)}`;

function nextUrl(value) {
  const target = new URL(value);
  const base = new URL(trinoUrl);
  target.protocol = base.protocol;
  target.host = base.host;
  return target.toString();
}

async function trino(sql) {
  const headers = {
    "X-Trino-User": trinoUser,
    "X-Trino-Catalog": catalog,
    "X-Trino-Schema": schema
  };
  let response = await fetch(`${trinoUrl}/v1/statement`, {
    method: "POST",
    headers: { ...headers, "Content-Type": "text/plain" },
    body: sql
  });

  let columns = [];
  const data = [];
  while (true) {
    if (!response.ok) throw new Error(`Trino returned HTTP ${response.status}`);
    const page = await response.json();
    if (page.error) throw new Error(page.error.message || "Trino query failed");
    if (page.columns) columns = page.columns.map((column) => column.name);
    if (page.data) data.push(...page.data);
    if (!page.nextUri) break;
    response = await fetch(nextUrl(page.nextUri), { headers });
  }

  return data.map((row) => Object.fromEntries(columns.map((column, index) => [column, row[index]])));
}

const literal = (value) => `'${String(value).replaceAll("'", "''")}'`;

function whereClause(query) {
  const filters = [
    ["status", "Ticket Status"],
    ["priority", "Ticket Priority"],
    ["channel", "Ticket Channel"]
  ];
  const predicates = filters
    .filter(([parameter]) => query[parameter] && query[parameter] !== "All")
    .map(([parameter, column]) => `${qid(column)} = ${literal(query[parameter])}`);
  return predicates.length ? `WHERE ${predicates.join(" AND ")}` : "";
}

app.get("/api/health", async (_req, res) => {
  try {
    const result = await trino(`SELECT 1 AS ok FROM ${source} LIMIT 1`);
    res.json({ ok: result.length === 1, source: `${catalog}.${schema}.${table}` });
  } catch (error) {
    res.status(503).json({ ok: false, error: error.message });
  }
});

app.get("/api/filters", async (_req, res) => {
  try {
    const [statuses, priorities, channels] = await Promise.all([
      trino(`SELECT DISTINCT ${qid("Ticket Status")} AS value FROM ${source} WHERE ${qid("Ticket Status")} IS NOT NULL ORDER BY 1`),
      trino(`SELECT DISTINCT ${qid("Ticket Priority")} AS value FROM ${source} WHERE ${qid("Ticket Priority")} IS NOT NULL ORDER BY 1`),
      trino(`SELECT DISTINCT ${qid("Ticket Channel")} AS value FROM ${source} WHERE ${qid("Ticket Channel")} IS NOT NULL ORDER BY 1`)
    ]);
    res.json({
      statuses: statuses.map((row) => row.value),
      priorities: priorities.map((row) => row.value),
      channels: channels.map((row) => row.value)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/dashboard", async (req, res) => {
  const where = whereClause(req.query);
  try {
    const queries = {
      kpis: `
        SELECT
          COUNT(*) AS total_tickets,
          COUNT_IF(LOWER(COALESCE(${qid("Ticket Status")}, '')) NOT IN ('closed', 'resolved')) AS active_tickets,
          ROUND(AVG(TRY_CAST(${qid("Customer Satisfaction Rating")} AS DOUBLE)), 2) AS avg_satisfaction,
          ROUND(AVG(DATE_DIFF('minute', TRY_CAST(${qid("First Response Time")} AS TIMESTAMP), TRY_CAST(${qid("Time to Resolution")} AS TIMESTAMP))) / 60.0, 1) AS avg_resolution_hours
        FROM ${source} ${where}`,
      status: `SELECT ${qid("Ticket Status")} AS label, COUNT(*) AS value FROM ${source} ${where} GROUP BY 1 ORDER BY 2 DESC`,
      priority: `SELECT ${qid("Ticket Priority")} AS label, COUNT(*) AS value FROM ${source} ${where} GROUP BY 1 ORDER BY 2 DESC`,
      channel: `SELECT ${qid("Ticket Channel")} AS label, COUNT(*) AS value FROM ${source} ${where} GROUP BY 1 ORDER BY 2 DESC`,
      type: `SELECT ${qid("Ticket Type")} AS label, COUNT(*) AS value FROM ${source} ${where} GROUP BY 1 ORDER BY 2 DESC`,
      product: `SELECT ${qid("Product Purchased")} AS label, COUNT(*) AS value FROM ${source} ${where} GROUP BY 1 ORDER BY 2 DESC LIMIT 10`,
      satisfaction: `SELECT CAST(TRY_CAST(${qid("Customer Satisfaction Rating")} AS INTEGER) AS VARCHAR) AS label, COUNT(*) AS value FROM ${source} ${where}${where ? " AND" : " WHERE"} TRY_CAST(${qid("Customer Satisfaction Rating")} AS INTEGER) IS NOT NULL GROUP BY 1 ORDER BY 1`,
      detail: `
        SELECT
          ${qid("Ticket ID")} AS ticket_id,
          ${qid("Product Purchased")} AS product,
          ${qid("Ticket Type")} AS ticket_type,
          ${qid("Ticket Status")} AS status,
          ${qid("Ticket Priority")} AS priority,
          ${qid("Ticket Channel")} AS channel,
          ${qid("Customer Satisfaction Rating")} AS satisfaction
        FROM ${source} ${where}
        ORDER BY TRY_CAST(${qid("Ticket ID")} AS BIGINT) DESC
        LIMIT 25`
    };

    const entries = await Promise.all(Object.entries(queries).map(async ([key, sql]) => [key, await trino(sql)]));
    res.json({ source: `${catalog}.${schema}.${table}`, refreshedAt: new Date().toISOString(), ...Object.fromEntries(entries) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.use("/vendor/chart.js", express.static(path.join(__dirname, "node_modules/chart.js/dist")));
app.use(express.static(path.join(__dirname, "public")));

app.listen(port, () => {
  console.log(`Ticket dashboard: http://localhost:${port}`);
  console.log(`Trino endpoint: ${trinoUrl}`);
  console.log(`Iceberg table: ${catalog}.${schema}.${table}`);
});
