'use strict';
const MAX_FILE = 8 * 1024 * 1024, MAX_BATCH = 12 * 1024 * 1024;
const RESERVED = ['admin.html', 'staticwebapp.config.json'];
function fail(status, message) { const e = new Error(message); e.status = status; throw e; }
function pathOK(path, marker = false) {
  if (typeof path !== 'string' || !path || path.length > 240 || !/^[A-Za-z0-9_ .\/-]+$/.test(path) || path.split('/').some(x => !x || x === '.' || x === '..' || x.trim() !== x || x.startsWith('.'))) fail(400, 'Invalid path. Use letters, numbers, spaces, underscores, hyphens and periods; no hidden or traversal paths.');
  if (path.split('/')[0].toLowerCase() === 'api' || RESERVED.some(r => path.toLowerCase() === r || path.toLowerCase().startsWith(r+'/'))) fail(400, 'The admin page and platform configuration are protected.');
  return path;
}
function rolesOK(roles) {
  if (!Array.isArray(roles) || !roles.length || roles.length > 20 || roles.some(x => typeof x !== 'string' || !/^[A-Za-z0-9_]{1,64}$/.test(x))) fail(400, 'Specify one or more valid roles.');
  return [...new Set(roles)];
}
function lockedRules() { return [{route:'/api/admin/*',allowedRoles:['swa_admin']},{route:'/admin.html',allowedRoles:['swa_admin']}]; }
function secureConfig(config) {
  if (!config || typeof config !== 'object' || Array.isArray(config)) fail(400,'Invalid platform configuration.');
  config.routes = [...lockedRules(), ...(config.routes || []).filter(r => !['/api/admin/*','/admin.html'].includes(r.route))];
  // Never put metadata before the immutable admin routes.
  return config;
}
module.exports = async function(context, req) {
  const respond = (status, body) => { context.res = {status, headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'},body}; };
  try {
    let user;
    try { user = JSON.parse(Buffer.from(req.headers['x-ms-client-principal'] || '', 'base64').toString('utf8')); } catch { fail(401,'Sign in to Static Web Apps first.'); }
    if (!user || !Array.isArray(user.userRoles) || !user.userRoles.includes('swa_admin')) fail(403,'The swa_admin role is required.');
    const action = req.params.action;
    if (!['state','content','publish'].includes(action)) fail(404,'Unknown operation.');
    if (action === 'publish') {
      if (req.method !== 'POST') fail(405,'POST required.');
      if (req.headers['x-swa-admin-request'] !== '1') fail(403,'Required request header missing.');
      let origin;
      try { origin = new URL(req.headers.origin).origin; } catch { fail(403,'A browser Origin header is required.'); }
      const allowed = (process.env.ADMIN_ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean);
      if (!allowed.includes(origin)) fail(403,'Origin is not in ADMIN_ALLOWED_ORIGINS.');
    } else if (req.method !== 'GET') fail(405,'GET required.');
    const {GITHUB_OWNER:owner,GITHUB_REPO:repo,GITHUB_TOKEN:token} = process.env;
    const branch = process.env.GITHUB_BRANCH || 'main', root = (process.env.STATIC_ROOT || 'public').replace(/\/$/,'');
    if (!owner || !repo || !token || !/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo) || !/^[A-Za-z0-9_/-]+$/.test(branch) || !/^[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(root)) fail(503,'Server repository settings are missing or invalid.');
    async function gh(path, method='GET', body) {
      const r = await fetch(`https://api.github.com/repos/${owner}/${repo}/${path}`, {method,headers:{Authorization:`Bearer ${token}`,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'SWA-File-Admin','Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
      if (!r.ok) { if ([409,422].includes(r.status)) fail(409,'Repository changed or rejected the update. Reload and review the branch protection rules.'); fail(502,`GitHub operation failed (${r.status}). Check token permissions, rate limits and repository settings.`); }
      return r.json();
    }
    const ref = await gh(`git/ref/heads/${branch}`), head = ref.object.sha;
    const commit = await gh(`git/commits/${head}`);
    const tree = await gh(`git/trees/${commit.tree.sha}?recursive=1`);
    if (tree.truncated) fail(413,'Repository tree is too large for this version of the admin tool.');
    const entries = tree.tree.filter(x=>x.type==='blob' && x.path.startsWith(root+'/'));
    const files = entries.map(x=>({path:x.path.slice(root.length+1),size:x.size,sha:x.sha,mode:x.mode}));
    const configEntry = files.find(x=>x.path==='staticwebapp.config.json');
    let config = {platform:{apiRuntime:'node:22'},routes:lockedRules()};
    if (configEntry) {
      const b = await gh(`git/blobs/${configEntry.sha}`);
      try { config = JSON.parse(Buffer.from(b.content,'base64').toString('utf8')); } catch { fail(409,'Existing staticwebapp.config.json is invalid. Fix it in the repository.'); }
    }
    if (action === 'state') return respond(200,{head,files,config,repository:`${owner}/${repo}`,branch,root,actionsUrl:`https://github.com/${owner}/${repo}/actions`});
    if (action === 'content') {
      const path = req.query.path;
      if (typeof path !== 'string') fail(400,'Path required.');
      const entry = files.find(x=>x.path===path);
      if (!entry || entry.mode==='120000') fail(404,'File not found or is a symlink.');
      if (entry.size > MAX_FILE) fail(413,'File exceeds the 8 MiB editor/download limit.');
      const b = await gh(`git/blobs/${entry.sha}`);
      return respond(200,{path,base64:b.content.replace(/\s/g,''),size:entry.size});
    }
    const body = req.body;
    if (!body || typeof body !== 'object' || body.head !== head) fail(409,'Repository has changed. Reload before publishing.');
    const operations = body.operations, permissions = body.permissions || [];
    if (!Array.isArray(operations) || !Array.isArray(permissions) || operations.length + permissions.length > 100 || !operations.length && !permissions.length) fail(400,'Supply 1–100 changes.');
    const updates = new Map(), seen=new Set(); let total = 0;
    for (const op of operations) {
      const path = pathOK(op.path);
      if (seen.has(path)) fail(400,'Duplicate file operation.');
      seen.add(path);
      if (op.type === 'deleteFolder') {
        const children=files.filter(f=>f.path.startsWith(path+'/'));
        if(!children.length) fail(400,'Cannot delete a nonexistent folder.');
        for(const child of children) updates.set(child.path,null);
      } else if (op.type === 'delete') {
        if (!files.some(x=>x.path===path)) fail(400,'Cannot delete a nonexistent file.');
        updates.set(path,null);
      } else if (op.type === 'put') {
        if (typeof op.base64 !== 'string') fail(400,'Invalid base64 file.');
        if(op.base64.length > Math.ceil(MAX_FILE/3)*4) fail(413,'File exceeds 8 MiB.');
        if (!/^[A-Za-z0-9+/]*={0,2}$/.test(op.base64) || Buffer.from(op.base64,'base64').toString('base64')!==op.base64) fail(400,'Invalid base64 file.');
        const bytes=Buffer.from(op.base64,'base64'); total+=bytes.length;
        if (bytes.length > MAX_FILE || total > MAX_BATCH) fail(413,'Use batches under 12 MiB and files under 8 MiB.');
        updates.set(path,{content:op.base64,encoding:'base64'});
      } else if (op.type === 'folder') updates.set(path+'/.swa-folder',{content:'',encoding:'utf-8'});
      else fail(400,'Unknown file operation.');
    }
    let routes = config.routes || [];
    for (const p of permissions) {
      const path=pathOK(p.path);
      const route='/'+path+(p.folder?'/*':'');
      if (!files.some(x=>x.path===path || p.folder && x.path.startsWith(path+'/')) && ![...updates.keys()].some(x=>x===path || p.folder && x.startsWith(path+'/'))) fail(400,'Permission target does not exist.');
      routes=routes.filter(x=>x.route!==route);
      if (p.roles !== null) routes.unshift({route,allowedRoles:rolesOK(p.roles)});
    }
    config.routes = routes;
    secureConfig(config);
    // Administrative path protections are restored on every commit.
    updates.set('staticwebapp.config.json',{content:JSON.stringify(config,null,2)+'\n',encoding:'utf-8'});
    const existing = new Map(files.map(f=>[f.path,f.size || 0]));
    for (const [path,data] of updates) { if (data === null) existing.delete(path); else existing.set(path,Buffer.from(data.content,data.encoding==='base64'?'base64':'utf8').length); }
    if (existing.size>15000 || [...existing.values()].reduce((a,b)=>a+b,0)>250*1024*1024) fail(413,'Deployment exceeds free-tier file count or 250 MiB size limit.');
    const names=[...existing.keys()];
    for(const name of names) { const parts=name.split('/'); for(let i=1;i<parts.length;i++) if(existing.has(parts.slice(0,i).join('/'))) fail(400,'A file conflicts with a folder path.'); }
    const pending=[...updates]; const items=[];
    for(let i=0;i<pending.length;i+=4) { const results=await Promise.all(pending.slice(i,i+4).map(async ([path,data])=>({path:root+'/'+path,mode:'100644',type:'blob',sha:data?(await gh('git/blobs','POST',data)).sha:null}))); items.push(...results); }
    const nextTree=await gh('git/trees','POST',{base_tree:commit.tree.sha,tree:items});
    const nextCommit=await gh('git/commits','POST',{message:`SWA admin: ${operations.length} file changes, ${permissions.length} access changes\n\nActor: ${String(user.userId || 'unknown').replace(/[\r\n]/g,'').slice(0,120)}`,tree:nextTree.sha,parents:[head]});
    await gh(`git/refs/heads/${branch}`,'PATCH',{sha:nextCommit.sha,force:false});
    respond(200,{head:nextCommit.sha,commitUrl:`https://github.com/${owner}/${repo}/commit/${nextCommit.sha}`,actionsUrl:`https://github.com/${owner}/${repo}/actions`,message:'Committed. GitHub Actions must finish deploying before changes take effect.'});
  } catch(e) { respond(e.status || 500,{error:e.status?e.message:'Operation failed. Check server logs; no success is implied. Reload repository state before retrying.'}); }
};
module.exports._test={pathOK,rolesOK,secureConfig};
