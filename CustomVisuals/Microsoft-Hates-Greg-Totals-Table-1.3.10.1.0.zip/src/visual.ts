"use strict";
import "./../style/visual.less";
import powerbi from "powerbi-visuals-api";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";
import { dataViewWildcard } from "powerbi-visuals-utils-dataviewutils";
import { valueFormatter } from "powerbi-visuals-utils-formattingutils";
import { VisualFormattingSettingsModel, aggregationItems } from "./settings";

import IVisual=powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions=powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions=powerbi.extensibility.visual.VisualUpdateOptions;
import IVisualEventService=powerbi.extensibility.IVisualEventService;
import ISelectionManager=powerbi.extensibility.ISelectionManager;
import DataViewTable=powerbi.DataViewTable;
import DataViewMatrix=powerbi.DataViewMatrix;
import DataViewMetadataColumn=powerbi.DataViewMetadataColumn;
import PrimitiveValue=powerbi.PrimitiveValue;

type SortState={column:number;direction:1|-1}|null;

export class Visual implements IVisual {
 private root:HTMLDivElement; private scroller:HTMLDivElement; private table:HTMLTableElement;
 private events:IVisualEventService; private host:powerbi.extensibility.visual.IVisualHost; private selection:ISelectionManager;
 private formattingService=new FormattingSettingsService(); private settings=new VisualFormattingSettingsModel();
 private sort:SortState=null; private lastOptions:VisualUpdateOptions; private loadingMore=false;
 private currentColumns:DataViewMetadataColumn[]=[];
 private specificColumnConfigured=false;

 constructor(options:VisualConstructorOptions){
  this.host=options.host;this.events=options.host.eventService;this.selection=options.host.createSelectionManager();
  this.root=document.createElement("div");this.root.className="ptr-root";this.root.tabIndex=0;
  this.scroller=document.createElement("div");this.scroller.className="ptr-scroller";
  this.table=document.createElement("table");this.table.className="ptr-table";
  this.scroller.appendChild(this.table);this.root.appendChild(this.scroller);options.element.appendChild(this.root);
  this.scroller.addEventListener("scroll",()=>this.onScroll());
 }

 public update(options:VisualUpdateOptions):void{
  this.events.renderingStarted(options);this.lastOptions=options;
  try{
   this.root.style.width=`${Math.max(0,options.viewport.width)}px`;this.root.style.height=`${Math.max(0,options.viewport.height)}px`;
   const view=options.dataViews?.find(v=>!!v.matrix)||options.dataViews?.[0];
   this.settings=this.formattingService.populateFormattingSettingsModel(VisualFormattingSettingsModel,view);
   const matrixData=this.matrixToTable(view?.matrix);if(!matrixData?.columns?.length){this.renderLanding();this.events.renderingFinished(options);return;}
   // Persist display positions per field, independently of query projections.
   matrixData.columns.forEach(col=>{if(!col.queryName)return;this.settings.columnOrder.slices.push(new formattingSettings.NumUpDown({name:"position",displayName:`${col.displayName} position (0 = automatic)`,description:"1 is leftmost. Smaller numbers appear first; 0 follows positioned fields.",value:this.columnPosition(col),selector:{metadata:col.queryName} as any}));});
   const data=this.applyColumnOrder(matrixData);
   if(this.sort&&this.currentColumns[this.sort.column]?.queryName!==data.columns[this.sort.column]?.queryName)this.sort=null;
   this.configureColumnDropdowns(data,view?.metadata.objects as any);
   data.columns.forEach(col=>{const width=Number((col.objects as any)?.layout?.columnWidth)||this.settings.layout.defaultColumnWidth.value;const slice=new formattingSettings.NumUpDown({name:"columnWidth",displayName:`${col.displayName} (px)`,value:width,selector:col.queryName?({metadata:col.queryName} as any):undefined});this.settings.layout.slices.push(slice);});
   this.render(data);this.events.renderingFinished(options);
  }catch(e){this.events.renderingFailed(options,String(e));}
 }

 private renderLanding():void{this.table.replaceChildren();const box=document.createElement("caption");box.className="ptr-landing";box.textContent="Add grouping fields to Columns and numeric fields or measures to Values.";this.table.appendChild(box);}

 private render(data:DataViewTable):void{
  this.table.replaceChildren();this.applyVisualStyles();
  this.table.setAttribute("aria-label",this.settings.accessibility.tableLabel.value||"Data table");
  const columns=data.columns;this.currentColumns=columns;const colgroup=document.createElement("colgroup");let explicitWidth=false,totalWidth=0;columns.forEach(col=>{const c=document.createElement("col");const w=Number((col.objects as any)?.layout?.columnWidth);if(Number.isFinite(w)&&w>0){c.style.width=`${w}px`;explicitWidth=true;totalWidth+=w;}else totalWidth+=this.settings.layout.defaultColumnWidth.value;colgroup.appendChild(c);});this.table.appendChild(colgroup);if(explicitWidth){this.table.style.tableLayout="fixed";this.table.style.width=`${Math.max(totalWidth,this.root.clientWidth)}px`;}let rows=data.rows.map((r,i)=>({values:r,index:i}));
  if(this.sort){const s=this.sort;rows.sort((a,b)=>this.compare(a.values[s.column],b.values[s.column])*s.direction);}
  const mins:number[]=[],maxs:number[]=[];
  columns.forEach((_,c)=>{const nums=rows.map(r=>Number(r.values[c])).filter(Number.isFinite);mins[c]=nums.length?Math.min(...nums):0;maxs[c]=nums.length?Math.max(...nums):0;});
  const head=document.createElement("thead"),hr=document.createElement("tr");
  columns.forEach((col,c)=>hr.appendChild(this.makeHeader(col,c)));head.appendChild(hr);this.table.appendChild(head);
  const body=document.createElement("tbody");
  rows.forEach((row,r)=>{const tr=document.createElement("tr");tr.dataset.row=String(row.index);columns.forEach((col,c)=>tr.appendChild(this.makeCell(data,row.values[c],col,c,r,mins[c],maxs[c])));tr.addEventListener("click",ev=>this.selectRow(data,row.index,ev));tr.addEventListener("contextmenu",ev=>{ev.preventDefault();try{const id=this.host.createSelectionIdBuilder().withTable(data,row.index).createSelectionId();this.selection.showContextMenu(id,{x:ev.clientX,y:ev.clientY});}catch{/* Matrix-backed synthetic rows don't expose table identities. */}});body.appendChild(tr);});
  this.table.appendChild(body);
  if(this.settings.totals.show.value)this.renderTotals(data,columns);
 }

 private makeHeader(col:DataViewMetadataColumn,index:number):HTMLTableCellElement{
  const th=document.createElement("th");th.scope="col";th.tabIndex=0;th.dataset.column=String(index);
  const label=document.createElement("span");label.textContent=col.displayName;th.appendChild(label);
  if(this.sort?.column===index){const arrow=document.createElement("span");arrow.className="ptr-sort";arrow.textContent=this.sort.direction===1?"▲":"▼";arrow.setAttribute("aria-hidden","true");th.appendChild(arrow);th.setAttribute("aria-sort",this.sort.direction===1?"ascending":"descending");}
  const action=()=>{this.sort=this.sort?.column===index?{column:index,direction:this.sort.direction===1?-1:1}:{column:index,direction:1};this.update(this.lastOptions);};
  th.addEventListener("click",action);th.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();action();}});
  const resizer=document.createElement("span");resizer.className="ptr-resizer";resizer.setAttribute("role","separator");resizer.setAttribute("aria-label",`Resize ${col.displayName}`);resizer.addEventListener("click",e=>e.stopPropagation());resizer.addEventListener("pointerdown",e=>this.beginColumnResize(e,resizer,th,col,index));th.appendChild(resizer);
  this.applySpecific(th,col,"header");return th;
 }

 private beginColumnResize(event:PointerEvent,handle:HTMLElement,header:HTMLTableCellElement,col:DataViewMetadataColumn,index:number):void{
  event.preventDefault();event.stopPropagation();const headers=Array.from(this.table.querySelectorAll("thead th")) as HTMLTableCellElement[],tableColumns=Array.from(this.table.querySelectorAll("col")) as HTMLTableColElement[],widths=headers.map(x=>Math.round(x.getBoundingClientRect().width));const startX=event.clientX,startWidth=widths[index],startTotal=widths.reduce((a,b)=>a+b,0);tableColumns.forEach((x,i)=>x.style.width=`${widths[i]}px`);this.table.style.tableLayout="fixed";this.table.style.width=`${Math.max(startTotal,this.root.clientWidth)}px`;handle.setPointerCapture(event.pointerId);
  const move=(e:PointerEvent)=>{const width=Math.max(40,Math.round(startWidth+e.clientX-startX));tableColumns[index].style.width=`${width}px`;header.style.width=`${width}px`;this.table.style.width=`${Math.max(startTotal-startWidth+width,this.root.clientWidth)}px`;};
  const finish=(e:PointerEvent)=>{move(e);handle.releasePointerCapture(e.pointerId);handle.removeEventListener("pointermove",move);handle.removeEventListener("pointerup",finish);handle.removeEventListener("pointercancel",finish);const finalWidths=headers.map(x=>Math.round(x.getBoundingClientRect().width));const merge=this.currentColumns.flatMap((column,i)=>column.queryName?[{objectName:"layout",selector:{metadata:column.queryName} as any,properties:{columnWidth:finalWidths[i]}}]:[]);if(merge.length)this.host.persistProperties({merge});};
  handle.addEventListener("pointermove",move);handle.addEventListener("pointerup",finish);handle.addEventListener("pointercancel",finish);
 }

 private makeCell(data:DataViewTable,value:PrimitiveValue,col:DataViewMetadataColumn,c:number,r:number,min:number,max:number):HTMLTableCellElement{
  const td=document.createElement("td");td.dataset.column=String(c);td.title=value==null?"":String(value);const target=this.matches(this.selectedValue(this.settings.elements.series),col);
  const category=(col.type as any)?.category||"";const raw=value==null?"":String(value);const isUrl=/^https?:\/\//i.test(raw);
  if(category==="ImageUrl"&&isUrl){const img=document.createElement("img");img.src=raw;img.alt=col.displayName;img.style.width=`${this.settings.image.width.value}px`;img.style.height=`${this.settings.image.height.value}px`;td.appendChild(img);}
  else if((category==="WebUrl"||isUrl)&&target&&this.settings.elements.webUrl.value){const a=document.createElement("a");a.href=raw;a.target="_blank";a.rel="noopener noreferrer";a.textContent=this.settings.url.values.value?"🔗":raw;a.setAttribute("aria-label",this.settings.url.values.value?`Open ${col.displayName}`:raw);td.appendChild(a);}
  else {const text=document.createElement("span");text.className="ptr-value";text.textContent=this.formatValue(value,col);td.appendChild(text);}
  const n=Number(value),numeric=Number.isFinite(n);
  const cellObjects=(data.rows[r].objects?.[c] as any)?.cellElements||(col.objects as any)?.cellElements||{};
  if(target&&this.settings.elements.backgroundColor.value){const fill=cellObjects.backgroundColorRule?.solid?.color||cellObjects.backgroundColorRule;if(typeof fill==="string")td.style.backgroundColor=fill;}
  if(target&&this.settings.elements.fontColor.value){const fill=cellObjects.fontColorRule?.solid?.color||cellObjects.fontColorRule;if(typeof fill==="string")td.style.color=fill;}
  if(numeric&&target&&this.settings.elements.icons.value){const ratio=max===min ? .5 : (n-min)/(max-min);const icon=document.createElement("span");icon.className="ptr-icon";icon.textContent=ratio>.66?"▲":ratio<.34?"▼":"●";icon.setAttribute("aria-label",ratio>.66?"High":ratio<.34?"Low":"Middle");td.prepend(icon);}
  if(numeric&&this.settings.spark.showDataBars.value){const ratio=max===min?1:(n-min)/(max-min);const bar=document.createElement("span");bar.className="ptr-data-bar";bar.style.width=`${Math.max(0,Math.min(100,ratio*100))}%`;bar.style.background=this.settings.spark.barColor.value.value;td.appendChild(bar);}
  this.applySpecific(td,col,"values");return td;
 }

 private renderTotals(data:DataViewTable,columns:DataViewMetadataColumn[]):void{
  const foot=document.createElement("tfoot"),tr=document.createElement("tr");const labelColumn=columns.findIndex(col=>!col.isMeasure);
  columns.forEach((col,c)=>{const td=document.createElement("td");const aggregation=String((col.objects as any)?.totals?.aggregation||"default");const provided=data.totals?.[c];let value:PrimitiveValue;
   if(aggregation==="default")value=c===labelColumn?this.settings.totals.label.value:(provided!==undefined?provided:null);else if(aggregation==="none")value=null;else value=this.aggregate(data.rows.map(r=>r[c]),aggregation);
   td.textContent=this.formatValue(value,col);this.applySpecific(td,col,"total");tr.appendChild(td);});foot.appendChild(tr);this.table.appendChild(foot);
 }

 private applySpecific(el:HTMLElement,col:DataViewMetadataColumn,area:"header"|"values"|"total"):void{
  if(!this.specificColumnConfigured||!this.matches(this.selectedValue(this.settings.specific.series),col))return;
  const enabled=area==="header"?this.settings.specific.applyHeader.value:area==="total"?this.settings.specific.applyTotal.value:this.settings.specific.applyValues.value;if(!enabled)return;
  el.style.color=this.settings.specific.textColor.value.value;el.style.backgroundColor=this.settings.specific.backgroundColor.value.value;el.style.textAlign=String(this.settings.specific.alignment.value.value) as any;
 }

 private applyVisualStyles():void{
  const s=this.settings,v=s.values,h=s.headers,g=s.grid;this.table.dataset.preset=this.selectedValue(s.style.preset)||"default";this.root.classList.toggle("ptr-high-contrast",this.host.colorPalette.isHighContrast);
  const css=this.table.style;css.setProperty("--value-font",v.fontFamily.value);css.setProperty("--value-size",`${v.fontSize.value||g.globalFontSize.value}px`);css.setProperty("--value-weight",v.bold.value?"700":"400");css.setProperty("--value-style",v.italic.value?"italic":"normal");css.setProperty("--value-decoration",v.underline.value?"underline":"none");css.setProperty("--value-color",v.textColor.value.value);css.setProperty("--value-bg",v.backgroundColor.value.value);css.setProperty("--alt-color",v.alternateTextColor.value.value);css.setProperty("--alt-bg",v.alternateBackgroundColor.value.value);css.setProperty("--value-wrap",v.textWrap.value?"normal":"nowrap");
  css.setProperty("--head-font",h.fontFamily.value);css.setProperty("--head-size",`${h.fontSize.value}px`);css.setProperty("--head-weight",h.bold.value?"700":"400");css.setProperty("--head-style",h.italic.value?"italic":"normal");css.setProperty("--head-decoration",h.underline.value?"underline":"none");css.setProperty("--head-color",h.textColor.value.value);css.setProperty("--head-bg",h.backgroundColor.value.value);css.setProperty("--head-align",String(h.alignment.value.value));css.setProperty("--head-wrap",h.textWrap.value?"normal":"nowrap");css.setProperty("--pad",`${g.rowPadding.value}px`);
  css.setProperty("--h-border",g.horizontalGrid.value?`${g.horizontalWidth.value}px solid ${g.horizontalColor.value.value}`:"none");css.setProperty("--v-border",g.verticalGrid.value?`${g.verticalWidth.value}px solid ${g.verticalColor.value.value}`:"none");css.setProperty("--outer",`${g.borderWidth.value}px solid ${g.borderColor.value.value}`);
  css.setProperty("--total-color",s.totals.textColor.value.value);css.setProperty("--total-bg",s.totals.backgroundColor.value.value);
  css.borderTop=g.borderTop.value?"var(--outer)":"none";css.borderBottom=g.borderBottom.value?"var(--outer)":"none";css.borderLeft=g.borderLeft.value?"var(--outer)":"none";css.borderRight=g.borderRight.value?"var(--outer)":"none";
  const behavior=String(s.layout.autoSizeBehavior.value.value);css.tableLayout=behavior==="fixed"?"fixed":"auto";css.width=behavior==="grow"?"100%":"max-content";if(behavior==="fixed")css.setProperty("--column-width",`${s.layout.defaultColumnWidth.value}px`);else css.removeProperty("--column-width");this.root.classList.toggle("ptr-focus",s.accessibility.highContrastFocus.value);
 }

 private formatValue(value:PrimitiveValue,col:DataViewMetadataColumn):string{if(value==null)return "";try{return valueFormatter.create({format:col.format,value:typeof value==="number"?value:undefined}).format(value);}catch{return String(value);}}
 private compare(a:PrimitiveValue,b:PrimitiveValue):number{if(a==null&&b==null)return 0;if(a==null)return 1;if(b==null)return -1;if(typeof a==="number"&&typeof b==="number")return a-b;return String(a).localeCompare(String(b),undefined,{numeric:true,sensitivity:"base"});}
 private configureColumnDropdowns(data:DataViewTable,objects:any):void{
  const items=data.columns.map(c=>({displayName:c.displayName,value:c.queryName||c.displayName}));
  const configure=(slice:any,stored:any)=>{slice.items=items;slice.value=items.find(i=>i.value===stored||i.displayName===stored)||items[0];};
  this.specificColumnConfigured=typeof objects?.specificColumn?.series==="string"&&objects.specificColumn.series.length>0;configure(this.settings.specific.series,objects?.specificColumn?.series);configure(this.settings.elements.series,objects?.cellElements?.series);configure(this.settings.totals.series,objects?.totals?.series);
  const elementColumn=data.columns.find(c=>this.matches(this.selectedValue(this.settings.elements.series),c))||data.columns[0];const wildcard=dataViewWildcard.createDataViewWildcardSelector(dataViewWildcard.DataViewWildcardMatchingOption.InstancesAndTotals) as any;const constant=elementColumn.queryName?({metadata:elementColumn.queryName} as any):undefined;
  [this.settings.elements.backgroundColorRule,this.settings.elements.fontColorRule].forEach(slice=>{slice.selector=wildcard;slice.altConstantSelector=constant;slice.instanceKind=powerbi.VisualEnumerationInstanceKinds.ConstantOrRule;});this.settings.elements.backgroundColorRule.visible=this.settings.elements.backgroundColor.value;this.settings.elements.fontColorRule.visible=this.settings.elements.fontColor.value;
  const selected=this.selectedValue(this.settings.totals.series);const column=data.columns.find(c=>this.matches(selected,c))||data.columns[0];const stored=String((column.objects as any)?.totals?.aggregation||"default");
  this.settings.totals.aggregation.items=aggregationItems;this.settings.totals.aggregation.value=aggregationItems.find(i=>i.value===stored)||aggregationItems[0];this.settings.totals.aggregation.selector=column.queryName?({metadata:column.queryName} as any):undefined;
 }
 private selectedValue(slice:any):string{return String(slice?.value?.value??slice?.value??"");}
 private columnPosition(column:DataViewMetadataColumn):number{
  const stored=Number((column.objects as any)?.columnOrder?.position);
  return Number.isFinite(stored)&&stored>=1?Math.floor(stored):0;
 }
 private applyColumnOrder(data:DataViewTable):DataViewTable{
  const order=data.columns.map((column,index)=>({index,position:this.columnPosition(column)||Number.POSITIVE_INFINITY})).sort((a,b)=>a.position-b.position||a.index-b.index).map(item=>item.index);
  return {...data,columns:order.map(i=>data.columns[i]),rows:(data.rows||[]).map(row=>Object.assign(order.map(i=>row[i]),row.objects?{objects:order.map(i=>row.objects[i])}:{})),totals:data.totals?order.map(i=>data.totals[i]):undefined};
 }
 private matrixToTable(matrix:DataViewMatrix|undefined):DataViewTable|undefined{
  if(!matrix)return undefined;const rawRowSources=(matrix.rows?.levels||[]).flatMap(level=>level.sources||[]);const rawValueSources=matrix.valueSources||[];
  type ProjectedColumn={source:DataViewMetadataColumn;kind:"row"|"value";sourceIndex:number;sequence:number};
  const projected:ProjectedColumn[]=[...rawRowSources.map((source,sourceIndex)=>({source,kind:"row" as const,sourceIndex,sequence:sourceIndex})),...rawValueSources.map((source,sourceIndex)=>({source,kind:"value" as const,sourceIndex,sequence:rawRowSources.length+sourceIndex}))];
  // Retain each matrix source's native order and offset. Display ordering is a
  // separate permutation applied to the completed table, including its totals.
  const ordered=projected;
  const columns=ordered.map(column=>column.source);if(!columns.length)return undefined;
  const rows:powerbi.DataViewTableRow[]=[];let grandValues:PrimitiveValue[]|undefined;
  const valuesOf=(cells:{[id:number]:powerbi.DataViewMatrixNodeValue}|undefined):PrimitiveValue[]=>{const result:PrimitiveValue[]=new Array(rawValueSources.length).fill(null);Object.entries(cells||{}).forEach(([key,cell],position)=>{const numericKey=Number(key);const index=cell?.valueSourceIndex??(Number.isFinite(numericKey)?numericKey%Math.max(1,rawValueSources.length):position);if(index>=0&&index<result.length)result[index]=cell?.value;});return result;};
  const valueFor=(column:ProjectedColumn,path:PrimitiveValue[],values:PrimitiveValue[])=>column.kind==="row"?(path[column.sourceIndex]??null):(values[column.sourceIndex]??null);
  const visit=(node:powerbi.DataViewMatrixNode,path:PrimitiveValue[]):void=>{const current=[...path];if(!node.isSubtotal&&typeof node.level==="number"){
   const offset=(matrix.rows.levels||[]).slice(0,node.level).reduce((count,level)=>count+(level.sources?.length||0),0);
   if(node.levelValues?.length){for(const group of node.levelValues)current[offset+(group.levelSourceIndex??0)]=group.value;}
   else current[offset+(node.levelSourceIndex??0)]=node.value;
  }if(node.isSubtotal){if(path.every(v=>v===undefined))grandValues=valuesOf(node.values);return;}if(node.children?.length){node.children.forEach(child=>visit(child,current));return;}if(node!==matrix.rows.root){const rawValues=valuesOf(node.values);rows.push(ordered.map(column=>valueFor(column,current,rawValues)) as powerbi.DataViewTableRow);}};
  if(matrix.rows.root.values)grandValues=valuesOf(matrix.rows.root.values);visit(matrix.rows.root,[]);const totals=ordered.map(column=>column.kind==="value"?(grandValues?.[column.sourceIndex]??null):null);return {columns,rows,totals} as DataViewTable;
 }
 private matches(setting:string,column:DataViewMetadataColumn):boolean{const value=setting.trim().toLocaleLowerCase();return !!value&&(value===String(column.queryName||"").toLocaleLowerCase()||value===column.displayName.trim().toLocaleLowerCase());}
 private aggregate(values:PrimitiveValue[],kind:string):PrimitiveValue{
  const present=values.filter(v=>v!==null&&v!==undefined);if(kind==="count")return present.length;if(kind==="distinctCount")return new Set(present.map(v=>v instanceof Date?v.getTime():String(v))).size;
  const numbers=present.map(Number).filter(Number.isFinite);if(!numbers.length)return null;if(kind==="sum")return numbers.reduce((a,b)=>a+b,0);if(kind==="average")return numbers.reduce((a,b)=>a+b,0)/numbers.length;if(kind==="minimum")return Math.min(...numbers);if(kind==="maximum")return Math.max(...numbers);
  const sorted=[...numbers].sort((a,b)=>a-b);if(kind==="median"){const m=Math.floor(sorted.length/2);return sorted.length%2?sorted[m]:(sorted[m-1]+sorted[m])/2;}const mean=numbers.reduce((a,b)=>a+b,0)/numbers.length;const variance=numbers.length>1?numbers.reduce((a,b)=>a+(b-mean)**2,0)/(numbers.length-1):0;return kind==="standardDeviation"?Math.sqrt(variance):variance;
 }
 private selectRow(data:DataViewTable,row:number,event:MouseEvent):void{if((this.host as any).allowInteractions===false)return;try{const id=this.host.createSelectionIdBuilder().withTable(data,row).createSelectionId();this.selection.select(id,event.ctrlKey||event.metaKey).then(ids=>{const key=(x:powerbi.visuals.ISelectionId)=>JSON.stringify(x.getSelector());const keys=new Set(ids.map(key));this.table.querySelectorAll("tbody tr").forEach(x=>{const rowId=this.host.createSelectionIdBuilder().withTable(data,Number((x as HTMLElement).dataset.row)).createSelectionId();x.classList.toggle("ptr-dim",ids.length>0&&!keys.has(key(rowId)));});});}catch{/* Some aggregate-only tables cannot form row identities. */}}
 private onScroll():void{if(this.loadingMore||!this.lastOptions)return;if(this.scroller.scrollTop+this.scroller.clientHeight<this.scroller.scrollHeight-120)return;const view=this.lastOptions.dataViews?.find(v=>!!v.matrix);if(view?.metadata?.segment){this.loadingMore=true;Promise.resolve(this.host.fetchMoreData()).finally(()=>{this.loadingMore=false;});}}
 public getFormattingModel():powerbi.visuals.FormattingModel{return this.formattingService.buildFormattingModel(this.settings);}
}
