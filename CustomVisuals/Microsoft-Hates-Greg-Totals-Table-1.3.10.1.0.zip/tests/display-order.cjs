// Synthetic converter tests: these verify alignment, not Power BI query execution.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),ts=require('typescript');
const source=fs.readFileSync('src/visual.ts','utf8');
const methods=source.slice(source.indexOf(' private columnPosition('),source.indexOf(' private matches('));
const context={};vm.runInNewContext(ts.transpile('class Converter {'+methods+'}\nglobalThis.Converter=Converter;', {target:ts.ScriptTarget.ES2020}),context);
const converter=new context.Converter();
const c=(name,isMeasure,role)=>({displayName:name,queryName:name,isMeasure,roles:{[role]:true}});
const c3=c('Column3',false,'columns'),c1=c('Column1',false,'columns'),sum=c('Sum of Column2',true,'columns'),measure=c('Measure',true,'measureValues');
const all=[c3,c1,sum,measure];
const matrix={rows:{levels:[{sources:[c3,c1]}],root:{children:[
 {isSubtotal:true,level:0,values:{0:{value:60},1:{value:58,valueSourceIndex:1}}},
 ...['A','B','C'].map((v,i)=>({level:0,levelValues:[{levelSourceIndex:1,value:v},{levelSourceIndex:0,value:v+v}],values:{0:{value:(i+1)*10},1:{value:(i+1)*10-2,valueSourceIndex:1}}}))
]}},valueSources:[sum,measure]};
function permutations(a){return a.length?a.flatMap((v,i)=>permutations(a.filter((_,j)=>j!==i)).map(p=>[v,...p])):[[]];}
for(const order of permutations(all)){
 order.forEach((field,index)=>field.objects={columnOrder:{position:index+1}});
 const original=converter.matrixToTable(matrix),result=converter.applyColumnOrder(original);
 assert.deepEqual(Array.from(result.columns,c=>c.queryName),order.map(c=>c.queryName));
 for(let i=0;i<3;i++){
  const v=['A','B','C'][i],cells={Column3:v+v,Column1:v,Measure:(i+1)*10-2,'Sum of Column2':(i+1)*10};
  assert.deepEqual(Array.from(result.rows[i]),order.map(c=>cells[c.queryName]));
 }
 const totals={Column3:null,Column1:null,Measure:58,'Sum of Column2':60};
 assert.deepEqual(Array.from(result.totals),order.map(c=>totals[c.queryName]));
 assert.deepEqual(Array.from(original.columns,c=>c.queryName),all.map(c=>c.queryName));
}
// Equal positions retain native order; invalid/unset positions follow positioned fields.
all.forEach(c=>delete c.objects);c3.objects={columnOrder:{position:2}};measure.objects={columnOrder:{position:2}};
sum.objects={columnOrder:{position:-5}};
assert.deepEqual(Array.from(converter.applyColumnOrder(converter.matrixToTable(matrix)).columns,c=>c.queryName),['Column3','Measure','Column1','Sum of Column2']);
all.forEach(c=>delete c.objects);
assert.deepEqual(Array.from(converter.applyColumnOrder(converter.matrixToTable(matrix)).columns,c=>c.queryName),all.map(c=>c.queryName));
// A zero and a BLANK model result are preserved without summing display rows.
matrix.rows.root.children[0].values={0:{value:0},1:{value:null,valueSourceIndex:1}};
assert.deepEqual(Array.from(converter.applyColumnOrder(converter.matrixToTable(matrix)).totals),[null,null,0,null]);
// Root totals (instead of a subtotal child) are supported too.
matrix.rows.root.children.shift();matrix.rows.root.values={0:{value:60},1:{value:58,valueSourceIndex:1}};
assert.deepEqual(Array.from(converter.matrixToTable(matrix).totals),[null,null,60,58]);
// Absence of host totals remains BLANK rather than a made-up local total.
delete matrix.rows.root.values;
assert.deepEqual(Array.from(converter.matrixToTable(matrix).totals),[null,null,null,null]);
console.log('PASS: 24 saved display orders across both roles; aligned rows and model totals; stable ties/reset; zero/BLANK/missing totals.');
