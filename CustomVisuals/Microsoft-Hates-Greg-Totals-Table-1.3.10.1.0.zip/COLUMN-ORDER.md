# Column order and Default totals — 3.10.0.0

Import the 3.10.0.0 PBIVIZ, replacing the existing visual.

Open **Format your visual > Column order**. Each field has a position control,
including fields from both Columns and Values. Set smaller numbers for fields
that should appear farther left. Set 0 to use automatic order after all fields
with positive positions. Equal positions retain the automatic relative order.
Set every position to 0 to return to automatic order.

For example:

| Field | Position |
| --- | ---: |
| Column3 | 1 |
| Column1 | 2 |
| Sum of Column2 | 3 |
| Measure | 4 |

To interleave a measure with text fields, set Measure to 2, Column1 to 3,
and Sum of Column2 to 4. Positions affect the rendered table, not the field wells
themselves. The settings are associated with field query identities rather than
display labels. If a field's aggregation changes its query identity, its position
may need to be assigned again.

Default totals use the values Power BI evaluates in the grand-total context.
They never sum the rendered measure results. Numeric grouping fields without
aggregation do not acquire a model total simply by receiving a display position.
Use an aggregation or put the numeric field in Values when a model total is needed.

The data roles, single matrix mapping, and subtotal configuration match 3.4.0.0.
The table mapping used in 3.9 has been removed. Automatic order is the native
matrix grouping sequence followed by its value-source sequence; use the position
controls when an arbitrary mix of groupings and measures is needed.

Validation: the visual builds successfully. Synthetic tests exercise all 24
display orders of the four sample fields, composite grouping values, saved
positions across both roles, stable ties, reset to automatic order, and model
totals including zero and BLANK. They validate data conversion and alignment,
not execution inside Power BI Desktop. Desktop integration remains to be verified.
