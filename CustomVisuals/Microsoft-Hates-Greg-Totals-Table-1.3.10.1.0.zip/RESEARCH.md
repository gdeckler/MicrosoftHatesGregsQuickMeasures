# Research basis

The implementation was designed against Microsoft's current Power BI developer documentation as of September 13, 2026.

- Developer visual overview and packaging: https://learn.microsoft.com/en-us/power-bi/developer/visuals/develop-power-bi-visuals
- Capabilities, data roles, table mappings, privileges, sorting and optional capabilities: https://learn.microsoft.com/en-us/power-bi/developer/visuals/capabilities
- Formatting model and helper utilities: https://learn.microsoft.com/en-us/power-bi/developer/visuals/utils-formatting-model
- Format pane structure: https://learn.microsoft.com/en-us/power-bi/developer/visuals/format-pane-general
- Format objects and property descriptors: https://learn.microsoft.com/en-us/power-bi/developer/visuals/objects-properties
- Conditional formatting and documented table/matrix limitations: https://learn.microsoft.com/en-us/power-bi/developer/visuals/conditional-format
- Dynamic format strings: https://learn.microsoft.com/en-us/power-bi/developer/visuals/dynamic-format
- Keyboard focus support: https://learn.microsoft.com/en-us/power-bi/developer/visuals/supportskeyboardfocus-feature
- Render lifecycle events for reliable export: https://learn.microsoft.com/en-us/power-bi/developer/visuals/event-service
- Visual API changelog, including improved table custom sorting and subtotals in API 5.1: https://learn.microsoft.com/en-us/power-bi/developer/visuals/changelog
- Packaging requirements: https://learn.microsoft.com/en-us/power-bi/developer/visuals/package-visual
- Microsoft samples index: https://learn.microsoft.com/en-us/power-bi/developer/visuals/samples

The native Table card inventory and ten presets were implemented from the detailed observed behavior supplied in the project brief. The native visual is not open source, so visual similarity and public API behavior are the meaningful parity targets; internal implementation parity is not possible.
