# Power Table Replica

A Power BI custom visual that closely emulates the native Table visual while remaining within the public custom-visual API. It targets Power BI Visuals API 5.11.1 and packages as a single `.pbiviz`.

## Install

1. In Power BI Desktop, choose **Insert > More visuals > From this device**.
2. Select the `.pbiviz` file from `dist`.
3. Add text, date, Boolean, or numeric grouping columns to **Columns** and summarized numeric fields or DAX measures to **Values**.

## Implemented behavior

- Separate **Columns** and **Values** field wells backed by a matrix data view and rendered as a flat table.
- Ten style presets in a dropdown: Default, None, Minimal, Bold header, Alternating rows, Contrast alternating rows, Flashy rows, Bold header flashy rows, Sparse, and Condensed.
- Mouse-driven column resizing from header edges, with widths persisted per bound field.
- Field-well ordering is preserved: top-to-bottom entries in Columns and Values render left-to-right within their respective table sections.
- Fit-to-content, grow-to-fit, and fixed-width layout modes.
- Dynamically generated pixel-width setting for every bound column, persisted against the column metadata selector.
- Horizontal and vertical gridline visibility, color, and thickness; outer edge controls; padding and global sizing.
- Value and header font family, size, bold, italic, underline, colors, wrapping, and alignment.
- Optional totals row with a column dropdown and independently persisted aggregation for every column: Default, None, Sum, Average, Minimum, Maximum, Count (Distinct), Count, Standard deviation, Variance, or Median. Default uses Power BI's model-evaluated table total; None leaves that column blank.
- Specific-column and Cell-elements selectors populated dynamically from the fields bound to Columns.
- Native Power BI `fx` conditional-formatting controls for selected-column background and font colors, with per-cell rule results applied when supplied by the host.
- Toggle-controlled directional icons and Web URL rendering for the selected column.
- Web URLs as text or link icons; Image URL category rendering with configurable dimensions.
- Optional in-cell numeric data bars.
- Click selection and cross-filtering, multi-select, keyboard-sortable headers, sticky header/total rows, incremental data fetching, model-aware number/date formatting, accessible table markup, and forced-color CSS.

## Important parity boundaries

The native Table is an internal Microsoft visual and has capabilities that are not exposed identically to third-party visuals.

- The public conditional-formatting API exposes native `fx` rules for colors, which this visual uses for Background color and Font color. It does not expose the native Table visual's icon-rule or Web-URL-rule editors to third-party visuals, so those remain functional toggles using the custom visual's own behavior. Microsoft also documents table/matrix limitations, so actual rule-result delivery can vary by Power BI host version.
- Specific-column, Cell-elements, and Totals selectors enumerate the fields currently bound to Columns and store stable query names, so renamed display labels do not break the association.
- **Default** uses the model-evaluated grand-total node requested through Power BI's matrix Total/Subtotal API. Summarized columns use their selected model aggregation, and DAX measures are reevaluated in the grand-total filter context rather than added from displayed cells. **None** suppresses the selected column's total. Explicit custom aggregation overrides operate on the rows delivered to the visual.
- Native sparklines are model objects created through Power BI's built-in visual workflow. A custom visual does not receive the same hidden sparkline payload through an ordinary table mapping. This visual supplies compact numeric data bars instead.
- Native totals, sorting, accessibility, export behavior, and interaction semantics can change with Power BI releases. The custom visual uses the corresponding public APIs and semantic HTML but cannot inherit unreleased internal behavior automatically.

## Build

```bash
npm install
npm run package
```

The packaged visual is written to `dist/`.

## Source notes

- `capabilities.json` defines the Columns bucket, table mapping, sorting, accessibility capability, and format-pane properties.
- `src/settings.ts` defines the current formatting model.
- `src/visual.ts` renders and interacts with the table.
- `style/visual.less` contains grid, preset, focus, and forced-color behavior.
