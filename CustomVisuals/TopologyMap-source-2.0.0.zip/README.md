# Topology Map for Power BI

Topology Map overlays line topology on an interactive raster-tile basemap. It accepts semantic-model coordinates, a GeoJSON/TopoJSON document stored in a model column, or a public CORS-enabled GeoJSON/TopoJSON URL.

## Build and install

1. Install Node.js and run `npm install`.
2. Run `npm run package`.
3. In Power BI Desktop choose **Visualizations > … > Import a visual from a file** and select the `.pbiviz` file in `dist`.

## Semantic-model coordinates

Bind decimal-degree columns to **Latitude** and **Longitude** and set them to **Don't summarize** when appropriate. **Line ID** splits rows into paths, **Point order** sets vertex order, **Elevation** appears in point tooltips, and **Label** supplies tooltip text. Line color, width, opacity, and markers are in **Format > Topology lines**.

## GeoJSON and TopoJSON

Bind a column containing the complete document to **GeoJSON / TopoJSON text**, or enter a public CORS-enabled URL under **Format > Map and data source**. For TopoJSON with multiple objects, enter the object name; blank selects the first. Feature collections, features, geometry collections, polygon outlines, multilines, and lines are supported.

## Elevation bands

Enable **Color by elevation** and set the interval in **Format > Elevation bands**. The default elevation property is `elevation_m`; this can be changed for other GeoJSON schemas. The visual calculates the required bands from the highest feature elevation and shows up to 12 color pickers with their numeric ranges. For an interval of 300, for example, the bands begin at 0, 300, 600, 900, and so on.

## Interactive basemap

The default **Raster tile URL template** is Esri World Imagery: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}`. The Leaflet renderer requires no Web Worker and is compatible with Power BI's opaque custom-visual sandbox. The visual fits the initial viewport to the topology and keeps the basemap synchronized with the lines during mouse-wheel, button, touch, and drag navigation. The tile URL is configurable, but its domain must be declared in `capabilities.json`. Configure minimum and maximum zoom, fit padding, navigation buttons, and attribution in the Format pane.

Enable **Show geographic labels** to overlay Esri's World Boundaries and Places reference tiles on the imagery. The label URL and opacity are configurable. **Elevation perspective** adds a lower-right oblique contour inset, projected from the topology's elevation property; its size, background, vertical exaggeration, and rotation angle are configurable. Use the inset's rotate-left, reset, and rotate-right buttons to turn the view in 15-degree increments.

Enable **Swap map and perspective** to make the elevation perspective the main view and move the interactive map into the lower-right inset. The inset width and height settings then control the map inset. Enable **Project raster imagery** to place the configured raster basemap imagery on the perspective's ground plane beneath the elevated topology lines; imagery opacity is independently configurable. The raster tile server must permit cross-origin image use.

Hover over a topology feature to see its name or label, elevation, line ID, geometry type, vertex count, feature ID, and other scalar properties supplied by the GeoJSON or TopoJSON source.

## Constraints

- External URLs require the visual's WebAccess privilege, tenant permission, and browser CORS support.
- Power BI supplies at most 30,000 rows to this visual. Simplify larger geometry or use a topology document.
- A basemap URL must be an XYZ raster template containing `{z}`, `{x}`, and `{y}`; MapLibre style JSON is not a raster tile URL.

## Development

`npm start` starts the developer visual; `npm run lint` runs ESLint; `npm run package` creates the package. Leaflet, D3, and topojson-client are open source. Custom source is under the included MIT license.
