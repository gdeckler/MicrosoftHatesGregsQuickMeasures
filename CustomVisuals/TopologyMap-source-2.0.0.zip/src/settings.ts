"use strict";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";
import FormattingSettingsCard = formattingSettings.SimpleCard;
import FormattingSettingsSlice = formattingSettings.Slice;
import FormattingSettingsModel = formattingSettings.Model;

class LineStyleCard extends FormattingSettingsCard {
    color = new formattingSettings.ColorPicker({ name:"color", displayName:"Line color", value:{value:"#00E5FF"} });
    width = new formattingSettings.NumUpDown({ name:"width", displayName:"Line width", value:2.5 });
    opacity = new formattingSettings.NumUpDown({ name:"opacity", displayName:"Line opacity (0–100)", value:90 });
    showPoints = new formattingSettings.ToggleSwitch({ name:"showPoints", displayName:"Show points", value:false });
    pointSize = new formattingSettings.NumUpDown({ name:"pointSize", displayName:"Point size", value:3 });
    name = "lineStyle"; displayName = "Topology lines";
    slices: FormattingSettingsSlice[] = [this.color,this.width,this.opacity,this.showPoints,this.pointSize];
}
class ElevationBandsCard extends FormattingSettingsCard {
    enabled = new formattingSettings.ToggleSwitch({ name:"enabled", displayName:"Color by elevation", value:true });
    interval = new formattingSettings.NumUpDown({ name:"interval", displayName:"Elevation interval", value:300 });
    propertyName = new formattingSettings.TextInput({ name:"propertyName", displayName:"GeoJSON elevation property", value:"elevation_m", placeholder:"elevation_m" });
    band1 = new formattingSettings.ColorPicker({ name:"band1", displayName:"Band 1", value:{value:"#313695"} });
    band2 = new formattingSettings.ColorPicker({ name:"band2", displayName:"Band 2", value:{value:"#4575B4"} });
    band3 = new formattingSettings.ColorPicker({ name:"band3", displayName:"Band 3", value:{value:"#74ADD1"} });
    band4 = new formattingSettings.ColorPicker({ name:"band4", displayName:"Band 4", value:{value:"#ABD9E9"} });
    band5 = new formattingSettings.ColorPicker({ name:"band5", displayName:"Band 5", value:{value:"#E0F3F8"} });
    band6 = new formattingSettings.ColorPicker({ name:"band6", displayName:"Band 6", value:{value:"#FFFFBF"} });
    band7 = new formattingSettings.ColorPicker({ name:"band7", displayName:"Band 7", value:{value:"#FEE090"} });
    band8 = new formattingSettings.ColorPicker({ name:"band8", displayName:"Band 8", value:{value:"#FDAE61"} });
    band9 = new formattingSettings.ColorPicker({ name:"band9", displayName:"Band 9", value:{value:"#F46D43"} });
    band10 = new formattingSettings.ColorPicker({ name:"band10", displayName:"Band 10", value:{value:"#D73027"} });
    band11 = new formattingSettings.ColorPicker({ name:"band11", displayName:"Band 11", value:{value:"#A50026"} });
    band12 = new formattingSettings.ColorPicker({ name:"band12", displayName:"Band 12+", value:{value:"#67001F"} });
    name="elevationBands"; displayName="Elevation bands";
    slices:FormattingSettingsSlice[]=[this.enabled,this.interval,this.propertyName,this.band1,this.band2,this.band3,this.band4,this.band5,this.band6,this.band7,this.band8,this.band9,this.band10,this.band11,this.band12];
    colors(){return [this.band1,this.band2,this.band3,this.band4,this.band5,this.band6,this.band7,this.band8,this.band9,this.band10,this.band11,this.band12];}
}
class MapCard extends FormattingSettingsCard {
    rasterTileUrl = new formattingSettings.TextInput({ name:"rasterTileUrl", displayName:"Raster tile URL template", value:"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", placeholder:"https://…/{z}/{x}/{y}.png" });
    topologyUrl = new formattingSettings.TextInput({ name:"topologyUrl", displayName:"GeoJSON / TopoJSON URL", value:"", placeholder:"https://…/topology.json" });
    topologyObjectName = new formattingSettings.TextInput({ name:"topologyObjectName", displayName:"TopoJSON object name", value:"", placeholder:"Blank = first object" });
    backgroundColor = new formattingSettings.ColorPicker({ name:"backgroundColor", displayName:"Fallback background", value:{value:"#101820"} });
    fitPadding = new formattingSettings.NumUpDown({ name:"fitPadding", displayName:"Fit padding", value:18 });
    minimumZoom = new formattingSettings.NumUpDown({ name:"minimumZoom", displayName:"Minimum zoom", value:0 });
    maximumZoom = new formattingSettings.NumUpDown({ name:"maximumZoom", displayName:"Maximum zoom", value:18 });
    showNavigation = new formattingSettings.ToggleSwitch({ name:"showNavigation", displayName:"Show zoom controls", value:true });
    showAttribution = new formattingSettings.ToggleSwitch({ name:"showAttribution", displayName:"Show attribution", value:true });
    attribution = new formattingSettings.TextInput({ name:"attribution", displayName:"Attribution text", value:"Tiles © Esri", placeholder:"Imagery source / copyright" });
    showLabels = new formattingSettings.ToggleSwitch({ name:"showLabels", displayName:"Show geographic labels", value:true });
    labelTileUrl = new formattingSettings.TextInput({ name:"labelTileUrl", displayName:"Label tile URL template", value:"https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", placeholder:"https://…/{z}/{y}/{x}" });
    labelOpacity = new formattingSettings.NumUpDown({ name:"labelOpacity", displayName:"Label opacity (0–100)", value:100 });
    name = "map"; displayName = "Map and data source";
    slices: FormattingSettingsSlice[] = [this.rasterTileUrl,this.topologyUrl,this.topologyObjectName,this.backgroundColor,this.fitPadding,this.minimumZoom,this.maximumZoom,this.showNavigation,this.showLabels,this.labelTileUrl,this.labelOpacity,this.showAttribution,this.attribution];
}
class PerspectiveInsetCard extends FormattingSettingsCard {
    show = new formattingSettings.ToggleSwitch({ name:"show", displayName:"Show elevation perspective", value:true });
    swapViews = new formattingSettings.ToggleSwitch({ name:"swapViews", displayName:"Swap map and perspective", value:false });
    width = new formattingSettings.NumUpDown({ name:"width", displayName:"Inset width", value:240 });
    height = new formattingSettings.NumUpDown({ name:"height", displayName:"Inset height", value:150 });
    exaggeration = new formattingSettings.NumUpDown({ name:"exaggeration", displayName:"Vertical exaggeration", value:1.5 });
    rotation = new formattingSettings.NumUpDown({ name:"rotation", displayName:"Rotation angle (degrees)", value:0 });
    showImagery = new formattingSettings.ToggleSwitch({ name:"showImagery", displayName:"Project raster imagery", value:false });
    imageryOpacity = new formattingSettings.NumUpDown({ name:"imageryOpacity", displayName:"Imagery opacity (0–100)", value:75 });
    background = new formattingSettings.ColorPicker({ name:"background", displayName:"Background", value:{value:"#101820"} });
    name="perspectiveInset"; displayName="Elevation perspective";
    slices:FormattingSettingsSlice[]=[this.show,this.swapViews,this.width,this.height,this.exaggeration,this.rotation,this.showImagery,this.imageryOpacity,this.background];
}
export class VisualFormattingSettingsModel extends FormattingSettingsModel {
    lineStyle = new LineStyleCard(); elevationBands = new ElevationBandsCard(); map = new MapCard(); perspectiveInset = new PerspectiveInsetCard();
    cards = [this.lineStyle,this.elevationBands,this.map,this.perspectiveInset];
}
