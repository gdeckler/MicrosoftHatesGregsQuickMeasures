"use strict";
import powerbi from "powerbi-visuals-api";
import * as d3 from "d3";
import * as L from "leaflet";
import { feature as topojsonFeature } from "topojson-client";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import "./../style/visual.less";
import { VisualFormattingSettingsModel } from "./settings";

import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import IVisualEventService = powerbi.extensibility.IVisualEventService;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import DataViewTable = powerbi.DataViewTable;
type Position=[number,number];
interface ModelPoint{lon:number;lat:number;elevation?:number;order:number;lineId:string;label?:string;}
const DEFAULT_TILES="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
const DEFAULT_LABELS="https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}";

export class Visual implements IVisual {
    private readonly events:IVisualEventService;
    private readonly host:IVisualHost;
    private readonly root:d3.Selection<HTMLDivElement,unknown,null,undefined>;
    private readonly mapElement:HTMLDivElement;
    private readonly status:d3.Selection<HTMLDivElement,unknown,null,undefined>;
    private readonly inset:d3.Selection<HTMLDivElement,unknown,null,undefined>;
    private readonly formattingService=new FormattingSettingsService();
    private formattingSettings=new VisualFormattingSettingsModel();
    private map:L.Map|null=null;
    private tileLayer:L.TileLayer|null=null;
    private labelLayer:L.TileLayer|null=null;
    private topologyLayer:L.GeoJSON|null=null;
    private zoomControl:L.Control.Zoom|null=null;
    private attributionControl:L.Control.Attribution|null=null;
    private currentTileUrl="";
    private currentLabelUrl="";
    private lastFittedKey="";
    private requestSerial=0;
    private cachedUrl="";
    private cachedRemote:GeoJSON.GeoJsonObject|null=null;
    private currentInsetGeo:GeoJSON.GeoJsonObject|null=null;
    private interactiveRotation:number|null=null;
    private lastConfiguredRotation:number|null=null;
    private viewportWidth=1;
    private viewportHeight=1;
    private imageryCacheKey="";
    private imageryCanvas:HTMLCanvasElement|null=null;
    private imageryLoadingKey="";
    private imageryFailedKey="";

    constructor(options:VisualConstructorOptions){
        this.host=options.host;
        this.events=options.host.eventService;
        this.root=d3.select(options.element).append("div").classed("topology-map",true);
        this.mapElement=document.createElement("div");this.mapElement.className="map-canvas";this.root.node()?.appendChild(this.mapElement);
        this.status=this.root.append("div").classed("status hidden",true);
        this.inset=this.root.append("div").classed("perspective-inset hidden",true);
    }

    public update(options:VisualUpdateOptions):void{
        this.events.renderingStarted(options);
        try{
            if(options.dataViews?.[0])this.formattingSettings=this.formattingService.populateFormattingSettingsModel(VisualFormattingSettingsModel,options.dataViews[0]);
            this.render(options).then(()=>this.events.renderingFinished(options)).catch((error:unknown)=>{
                this.showStatus(`Unable to render topology: ${this.message(error)}`,true);this.events.renderingFailed(options,this.message(error));
            });
        }catch(error){this.showStatus(`Unable to render topology: ${this.message(error)}`,true);this.events.renderingFailed(options,this.message(error));}
    }

    public getFormattingModel():powerbi.visuals.FormattingModel{return this.formattingService.buildFormattingModel(this.formattingSettings);}
    public destroy():void{this.map?.remove();this.map=null;}

    private async render(options:VisualUpdateOptions):Promise<void>{
        const serial=++this.requestSerial,width=Math.max(1,Math.floor(options.viewport.width)),height=Math.max(1,Math.floor(options.viewport.height));
        this.viewportWidth=width;this.viewportHeight=height;
        this.root.style("width",`${width}px`).style("height",`${height}px`).style("background",this.formattingSettings.map.backgroundColor.value.value);
        this.applyViewLayout(width,height);
        this.ensureMap();this.map?.invalidateSize(false);this.syncBasemap();this.syncLabels();this.syncControls();

        const table=options.dataViews?.[0]?.table,embedded=this.extractTopologyText(table),modelPoints=this.extractModelPoints(table);
        let geo:GeoJSON.GeoJsonObject|null=null,source="",dataKey="";
        if(embedded){geo=this.parseTopology(embedded,this.formattingSettings.map.topologyObjectName.value);source="semantic-model topology";dataKey=`embedded:${embedded.length}:${embedded.slice(0,80)}`;}
        else if(modelPoints.length){geo=this.pointsToGeoJson(modelPoints);source=`${modelPoints.length.toLocaleString()} semantic-model points`;dataKey=`points:${modelPoints.length}:${modelPoints[0]?.lon}:${modelPoints.at(-1)?.lat}`;}
        else{const url=this.formattingSettings.map.topologyUrl.value.trim();if(url){geo=await this.fetchTopology(url,this.formattingSettings.map.topologyObjectName.value);source="remote topology";dataKey=`url:${url}`;}}
        if(serial!==this.requestSerial)return;
        this.removeTopology();
        if(!geo){this.currentInsetGeo=null;this.inset.classed("hidden",true);this.showStatus("Add Latitude + Longitude fields, a GeoJSON/TopoJSON text field, or a topology URL.",false);return;}
        this.updateElevationSettings(geo);
        const swapped=this.formattingSettings.perspectiveInset.show.value&&this.formattingSettings.perspectiveInset.swapViews.value;
        this.drawTopology(geo,modelPoints,`${dataKey}:layout:${swapped}:${this.mapElement.style.width}:${this.mapElement.style.height}`);
        const configuredRotation=this.normalizeAngle(this.formattingSettings.perspectiveInset.rotation.value);
        if(this.interactiveRotation===null||this.lastConfiguredRotation!==configuredRotation)this.interactiveRotation=configuredRotation;
        this.lastConfiguredRotation=configuredRotation;
        this.currentInsetGeo=geo;
        this.drawPerspectiveInset(geo);
        this.showStatus(source,false,true);
    }

    private applyViewLayout(width:number,height:number):void{
        const swapped=this.formattingSettings.perspectiveInset.show.value&&this.formattingSettings.perspectiveInset.swapViews.value;
        const insetWidth=Math.max(140,Math.min(width-20,600,this.formattingSettings.perspectiveInset.width.value));
        const insetHeight=Math.max(90,Math.min(height-20,400,this.formattingSettings.perspectiveInset.height.value));
        this.mapElement.classList.toggle("map-inset",swapped);
        this.mapElement.style.width=`${swapped?insetWidth:width}px`;this.mapElement.style.height=`${swapped?insetHeight:height}px`;
        this.inset.classed("perspective-main",swapped);
    }

    private ensureMap():void{
        const minZoom=Math.max(0,Math.min(22,this.formattingSettings.map.minimumZoom.value));
        const maxZoom=Math.max(minZoom,Math.min(22,this.formattingSettings.map.maximumZoom.value));
        if(!this.map)this.map=L.map(this.mapElement,{center:[7.9,80.7],zoom:6,minZoom,maxZoom,zoomControl:false,attributionControl:false,preferCanvas:false});
        else{this.map.setMinZoom(minZoom);this.map.setMaxZoom(maxZoom);}
        const tooltipPane=this.map.getPane("tooltipPane");if(tooltipPane)tooltipPane.style.zIndex="750";
    }

    private syncBasemap():void{
        if(!this.map)return;
        const url=this.formattingSettings.map.rasterTileUrl.value.trim()||DEFAULT_TILES;
        if(url===this.currentTileUrl&&this.tileLayer)return;
        if(this.tileLayer)this.map.removeLayer(this.tileLayer);
        this.currentTileUrl=url;
        this.tileLayer=L.tileLayer(url,{minZoom:this.map.getMinZoom(),maxZoom:this.map.getMaxZoom(),subdomains:"abcd",crossOrigin:true});
        this.tileLayer.on("tileerror",()=>this.showStatus("A basemap tile could not be loaded. Verify the raster XYZ tile URL and its WebAccess domain.",true));
        this.tileLayer.addTo(this.map);
    }

    private syncLabels():void{
        if(!this.map)return;
        const enabled=this.formattingSettings.map.showLabels.value;
        const url=this.formattingSettings.map.labelTileUrl.value.trim()||DEFAULT_LABELS;
        if(!enabled){if(this.labelLayer){this.map.removeLayer(this.labelLayer);this.labelLayer=null;}this.currentLabelUrl="";return;}
        const opacity=this.percent(this.formattingSettings.map.labelOpacity.value);
        if(this.labelLayer&&url===this.currentLabelUrl){this.labelLayer.setOpacity(opacity);return;}
        if(this.labelLayer)this.map.removeLayer(this.labelLayer);
        if(!this.map.getPane("labels")){const pane=this.map.createPane("labels");pane.style.zIndex="650";pane.style.pointerEvents="none";}
        this.currentLabelUrl=url;
        this.labelLayer=L.tileLayer(url,{minZoom:this.map.getMinZoom(),maxZoom:this.map.getMaxZoom(),opacity,pane:"labels",crossOrigin:true});
        this.labelLayer.on("tileerror",()=>this.showStatus("A geographic label tile could not be loaded. Verify its URL and WebAccess domain.",true));
        this.labelLayer.addTo(this.map);
    }

    private syncControls():void{
        if(!this.map)return;
        if(this.formattingSettings.map.showNavigation.value&&!this.zoomControl){this.zoomControl=L.control.zoom({position:"topright"}).addTo(this.map);}
        else if(!this.formattingSettings.map.showNavigation.value&&this.zoomControl){this.zoomControl.remove();this.zoomControl=null;}
        if(this.attributionControl){this.attributionControl.remove();this.attributionControl=null;}
        if(this.formattingSettings.map.showAttribution.value){
            this.attributionControl=L.control.attribution({position:"bottomright",prefix:false});
            this.attributionControl.addAttribution(this.formattingSettings.map.attribution.value.trim()||"Tiles © Esri");
            this.attributionControl.addTo(this.map);
        }
    }

    private drawTopology(geo:GeoJSON.GeoJsonObject,modelPoints:ModelPoint[],dataKey:string):void{
        if(!this.map)return;
        const baseColor=this.formattingSettings.lineStyle.color.value.value;
        const width=Math.max(.1,Math.min(30,this.formattingSettings.lineStyle.width.value));
        const opacity=this.percent(this.formattingSettings.lineStyle.opacity.value);
        const pointRadius=Math.max(.5,Math.min(20,this.formattingSettings.lineStyle.pointSize.value));
        this.topologyLayer=L.geoJSON(geo as any,{
            style:(feature)=>({color:this.featureColor(feature as GeoJSON.Feature,baseColor),weight:width,opacity,fill:false}),
            pointToLayer:(_feature,latlng)=>L.circleMarker(latlng,{radius:pointRadius,color:"#fff",weight:1,fillColor:baseColor,fillOpacity:opacity}),
            filter:(feature)=>feature.geometry?.type!=="Point"||this.formattingSettings.lineStyle.showPoints.value,
            onEachFeature:(feature,layer)=>layer.bindTooltip(this.featureTooltip(feature as GeoJSON.Feature),{sticky:true,direction:"top",opacity:.96,className:"topology-tooltip"})
        }).addTo(this.map);
        if(modelPoints.length&&this.formattingSettings.lineStyle.showPoints.value){
            modelPoints.forEach(point=>L.circleMarker([point.lat,point.lon],{radius:pointRadius,color:"#fff",weight:1,fillColor:baseColor,fillOpacity:opacity})
                .bindTooltip(this.pointTitle(point)).addTo(this.topologyLayer as unknown as L.LayerGroup));
        }
        const bounds=this.topologyLayer.getBounds();
        if(bounds.isValid()&&this.lastFittedKey!==dataKey){
            this.map.fitBounds(bounds,{padding:[Math.max(0,this.formattingSettings.map.fitPadding.value),Math.max(0,this.formattingSettings.map.fitPadding.value)],animate:false});
            this.lastFittedKey=dataKey;
        }
        this.topologyLayer.bringToFront();
    }

    private removeTopology():void{if(this.map&&this.topologyLayer){this.map.removeLayer(this.topologyLayer);this.topologyLayer=null;}}

    private featureTooltip(feature:GeoJSON.Feature):string{
        const properties=feature.properties||{},elevationProperty=this.formattingSettings.elevationBands.propertyName.value.trim()||"elevation_m";
        const priority=["name","title","label","lineId","line_id",elevationProperty,"elevation_m","elevation"];
        const keys=Object.keys(properties).filter(key=>this.tooltipValue(properties[key])!==null);
        keys.sort((a,b)=>{const ai=priority.indexOf(a),bi=priority.indexOf(b);return(ai<0?999:ai)-(bi<0?999:bi)||a.localeCompare(b);});
        const headingKey=keys.find(key=>["name","title","label"].includes(key));
        const heading=headingKey?String(properties[headingKey]):"Topology line";
        const rows:Array<[string,string]>=[["Geometry",feature.geometry?.type||"Unknown"]];
        if(feature.id!==undefined)rows.push(["Feature ID",String(feature.id)]);
        const vertices=this.vertexCount(feature.geometry);if(vertices>0)rows.push(["Vertices",vertices.toLocaleString()]);
        keys.filter(key=>key!==headingKey).slice(0,16).forEach(key=>rows.push([this.friendlyPropertyName(key),this.tooltipValue(properties[key]) as string]));
        const body=rows.map(([key,value])=>`<div class="topology-tooltip-row"><span>${this.escapeHtml(key)}</span><strong>${this.escapeHtml(value)}</strong></div>`).join("");
        return `<div class="topology-tooltip-content"><div class="topology-tooltip-title">${this.escapeHtml(heading)}</div>${body}</div>`;
    }

    private tooltipValue(value:unknown):string|null{
        if(value===null||value===undefined||value==="")return null;
        if(typeof value==="number")return Number.isFinite(value)?value.toLocaleString():null;
        if(typeof value==="boolean")return value?"Yes":"No";
        if(typeof value==="string")return value.length>240?`${value.slice(0,237)}…`:value;
        try{const text=JSON.stringify(value);return text.length>240?`${text.slice(0,237)}…`:text;}catch{return null;}
    }

    private friendlyPropertyName(key:string):string{return key.replace(/[_-]+/g," ").replace(/([a-z])([A-Z])/g,"$1 $2").replace(/^./,value=>value.toUpperCase());}
    private escapeHtml(value:string):string{return value.replace(/[&<>"']/g,character=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[character] as string));}
    private vertexCount(geometry:GeoJSON.Geometry|null):number{
        if(!geometry)return 0;
        if(geometry.type==="Point")return 1;
        if(geometry.type==="LineString"||geometry.type==="MultiPoint")return geometry.coordinates.length;
        if(geometry.type==="Polygon"||geometry.type==="MultiLineString")return geometry.coordinates.reduce((sum,line)=>sum+line.length,0);
        if(geometry.type==="MultiPolygon")return geometry.coordinates.reduce((sum,polygon)=>sum+polygon.reduce((inner,ring)=>inner+ring.length,0),0);
        if(geometry.type==="GeometryCollection")return geometry.geometries.reduce((sum,child)=>sum+this.vertexCount(child),0);
        return 0;
    }

    private featureColor(feature:GeoJSON.Feature,fallback:string):string{
        if(!this.formattingSettings.elevationBands.enabled.value)return fallback;
        const property=this.formattingSettings.elevationBands.propertyName.value.trim()||"elevation_m";
        const raw=feature.properties?.[property]??feature.properties?.elevation_m??feature.properties?.elevation;
        const elevation=Number(raw);if(!Number.isFinite(elevation))return fallback;
        const interval=Math.max(1,this.formattingSettings.elevationBands.interval.value);
        const index=Math.max(0,Math.min(11,Math.floor(elevation/interval)));
        return this.formattingSettings.elevationBands.colors()[index].value.value;
    }

    private updateElevationSettings(geo:GeoJSON.GeoJsonObject):void{
        const interval=Math.max(1,this.formattingSettings.elevationBands.interval.value),property=this.formattingSettings.elevationBands.propertyName.value.trim()||"elevation_m";
        let maximum=0;
        const examine=(feature:GeoJSON.Feature):void=>{const value=Number(feature.properties?.[property]??feature.properties?.elevation_m??feature.properties?.elevation);if(Number.isFinite(value))maximum=Math.max(maximum,value);};
        if(geo.type==="FeatureCollection")(geo as GeoJSON.FeatureCollection).features.forEach(examine);else if(geo.type==="Feature")examine(geo as GeoJSON.Feature);
        const count=Math.max(1,Math.min(12,Math.floor(maximum/interval)+1));
        this.formattingSettings.elevationBands.colors().forEach((color,index)=>{color.visible=this.formattingSettings.elevationBands.enabled.value&&index<count;const low=index*interval;color.displayName=index===11?`${low.toLocaleString()}+`:`${low.toLocaleString()}–${(low+interval-1).toLocaleString()}`;});
    }

    private drawPerspectiveInset(geo:GeoJSON.GeoJsonObject,loadedImagery?:HTMLCanvasElement|null):void{
        if(!this.formattingSettings.perspectiveInset.show.value){this.inset.classed("hidden",true);return;}
        const swapped=this.formattingSettings.perspectiveInset.swapViews.value;
        const width=swapped?this.viewportWidth:Math.max(140,Math.min(600,this.formattingSettings.perspectiveInset.width.value));
        const height=swapped?this.viewportHeight:Math.max(90,Math.min(400,this.formattingSettings.perspectiveInset.height.value));
        const exaggeration=Math.max(.1,Math.min(8,this.formattingSettings.perspectiveInset.exaggeration.value));
        const rotation=this.normalizeAngle(this.interactiveRotation??this.formattingSettings.perspectiveInset.rotation.value);
        const lines=this.contourLines(geo);
        if(!lines.length){this.inset.classed("hidden",true);return;}
        let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity,maxElevation=1;
        lines.forEach(line=>{maxElevation=Math.max(maxElevation,line.elevation);line.coordinates.forEach(point=>{minX=Math.min(minX,point[0]);maxX=Math.max(maxX,point[0]);minY=Math.min(minY,point[1]);maxY=Math.max(maxY,point[1]);});});
        const dx=Math.max(1e-9,maxX-minX),dy=Math.max(1e-9,maxY-minY),angle=rotation*Math.PI/180,cos=Math.cos(angle),sin=Math.sin(angle);
        const rotate=(point:Position):Position=>{const x=(point[0]-minX)/dx-.5,y=(point[1]-minY)/dy-.5;return[x*cos-y*sin,x*sin+y*cos];};
        let minRX=Infinity,maxRX=-Infinity,minRY=Infinity,maxRY=-Infinity;
        lines.forEach(line=>line.coordinates.forEach(point=>{const [x,y]=rotate(point);minRX=Math.min(minRX,x);maxRX=Math.max(maxRX,x);minRY=Math.min(minRY,y);maxRY=Math.max(maxRY,y);}));
        const drx=Math.max(1e-9,maxRX-minRX),dry=Math.max(1e-9,maxRY-minRY),pad=12,title=14;
        const depth=swapped?Math.min(height*.3,Math.max(70,height*.24)):Math.min(34,height*.24);
        const elevationHeight=swapped?Math.min(height*.58,height*.3*exaggeration):Math.min(height*.55,72*exaggeration);
        const usableWidth=Math.max(1,width-pad*2-depth),baseY=height-pad;
        const project=(point:Position,elevation:number):Position=>{const [rx,ry]=rotate(point),nx=(rx-minRX)/drx,ny=(ry-minRY)/dry;return[pad+nx*usableWidth+(1-ny)*depth,baseY-ny*depth-(elevation/maxElevation)*elevationHeight];};
        this.inset.classed("hidden",false).classed("perspective-main",swapped).style("width",`${width}px`).style("height",`${height}px`).style("background",this.formattingSettings.perspectiveInset.background.value.value);
        this.inset.selectAll("*").remove();
        const canvas=this.inset.append("canvas").attr("aria-label","Oblique elevation perspective of topology lines").node() as HTMLCanvasElement;
        const controls=this.inset.append("div").classed("perspective-controls",true).attr("role","group").attr("aria-label","Elevation perspective rotation controls");
        this.addRotationButton(controls,"↶","Rotate left",-15);
        this.addRotationButton(controls,"⟳","Reset rotation",0,true);
        this.addRotationButton(controls,"↷","Rotate right",15);
        const scale=Math.max(1,window.devicePixelRatio||1);canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);canvas.style.width=`${width}px`;canvas.style.height=`${height}px`;
        const context=canvas.getContext("2d");if(!context)return;context.scale(scale,scale);
        const imageryUrl=this.formattingSettings.map.rasterTileUrl.value.trim()||DEFAULT_TILES;
        const imageryKey=this.perspectiveImageryKey(imageryUrl,minX,maxX,minY,maxY);
        const cachedImagery=this.imageryCacheKey===imageryKey?this.imageryCanvas:null;
        const imagery=loadedImagery===undefined?cachedImagery:loadedImagery;
        if(this.formattingSettings.perspectiveInset.showImagery.value&&imagery)this.drawProjectedImagery(context,imagery,cos,sin,minRX,maxRX,minRY,maxRY,drx,dry,usableWidth,depth,pad,baseY);
        context.font="600 10px Segoe UI";context.fillStyle="#fff";context.fillText(`Elevation perspective · ${rotation}°`,8,12);
        context.beginPath();context.setLineDash([3,2]);context.strokeStyle="rgba(135,206,235,.75)";context.lineWidth=1;context.moveTo(pad,baseY);context.lineTo(width-pad,baseY-depth);context.stroke();context.setLineDash([]);
        context.font="8px Segoe UI";context.fillStyle="rgba(210,240,255,.9)";context.fillText("sea level",pad,baseY-3);context.textAlign="right";context.fillText(`${Math.round(maxElevation).toLocaleString()} max`,width-pad,12);context.textAlign="left";
        context.lineWidth=Math.max(.7,Math.min(2.5,this.formattingSettings.lineStyle.width.value*.55));context.globalAlpha=this.percent(this.formattingSettings.lineStyle.opacity.value);
        lines.sort((a,b)=>a.elevation-b.elevation).forEach(line=>{
            const projected=line.coordinates.map(point=>project(point,line.elevation));
            context.beginPath();context.strokeStyle=line.color;projected.forEach((point,index)=>index?context.lineTo(point[0],point[1]):context.moveTo(point[0],point[1]));context.stroke();
        });
        context.globalAlpha=1;
        if(this.formattingSettings.perspectiveInset.showImagery.value&&!imagery&&this.imageryLoadingKey!==imageryKey&&this.imageryFailedKey!==imageryKey){
            this.imageryLoadingKey=imageryKey;
            this.loadPerspectiveImagery(imageryUrl,minX,maxX,minY,maxY,width).then(image=>{
                if(this.imageryLoadingKey===imageryKey)this.imageryLoadingKey="";
                if(!image){this.imageryFailedKey=imageryKey;return;}
                this.imageryCacheKey=imageryKey;this.imageryCanvas=image;this.imageryFailedKey="";
                if(this.currentInsetGeo===geo&&this.formattingSettings.perspectiveInset.showImagery.value)this.drawPerspectiveInset(geo,image);
            }).catch(()=>{if(this.imageryLoadingKey===imageryKey)this.imageryLoadingKey="";this.imageryFailedKey=imageryKey;});
        }
    }

    private drawProjectedImagery(context:CanvasRenderingContext2D,image:HTMLCanvasElement,cos:number,sin:number,minRX:number,maxRX:number,minRY:number,maxRY:number,drx:number,dry:number,usableWidth:number,depth:number,pad:number,baseY:number):void{
        const textureWidth=Math.max(128,Math.min(1024,Math.round(usableWidth))),textureHeight=Math.max(128,Math.min(1024,Math.round(textureWidth*dry/drx)));
        const rotated=document.createElement("canvas");rotated.width=textureWidth;rotated.height=textureHeight;
        const rc=rotated.getContext("2d");if(!rc)return;
        const a=cos*textureWidth/(image.width*drx),b=-sin*textureHeight/(image.width*dry),c=sin*textureWidth/(image.height*drx),d=cos*textureHeight/(image.height*dry);
        const e=(-.5*(cos+sin)-minRX)*textureWidth/drx,f=(maxRY-.5*(cos-sin))*textureHeight/dry;
        rc.setTransform(a,b,c,d,e,f);rc.drawImage(image,0,0);
        context.save();context.globalAlpha=this.percent(this.formattingSettings.perspectiveInset.imageryOpacity.value);
        context.transform(usableWidth/textureWidth,0,depth/textureHeight,depth/textureHeight,pad,baseY-depth);context.drawImage(rotated,0,0);context.restore();
    }

    private perspectiveImageryKey(url:string,minX:number,maxX:number,minY:number,maxY:number):string{return`${url}|${minX.toFixed(6)}|${maxX.toFixed(6)}|${minY.toFixed(6)}|${maxY.toFixed(6)}`;}

    private async loadPerspectiveImagery(url:string,minLon:number,maxLon:number,minLat:number,maxLat:number,targetWidth:number):Promise<HTMLCanvasElement|null>{
        const clampLat=(lat:number)=>Math.max(-85.05112878,Math.min(85.05112878,lat));
        const lonSpan=Math.max(.000001,maxLon-minLon);let zoom=Math.max(1,Math.min(18,Math.floor(Math.log2(Math.max(256,targetWidth)*360/(256*lonSpan)))));
        const tileX=(lon:number,z:number)=>(lon+180)/360*Math.pow(2,z);
        const tileY=(lat:number,z:number)=>{const radians=clampLat(lat)*Math.PI/180;return(1-Math.log(Math.tan(radians)+1/Math.cos(radians))/Math.PI)/2*Math.pow(2,z);};
        let x0=0,x1=0,y0=0,y1=0;
        while(zoom>1){x0=tileX(minLon,zoom);x1=tileX(maxLon,zoom);y0=tileY(maxLat,zoom);y1=tileY(minLat,zoom);if((Math.ceil(x1)-Math.floor(x0))*(Math.ceil(y1)-Math.floor(y0))<=64)break;zoom--;}
        x0=tileX(minLon,zoom);x1=tileX(maxLon,zoom);y0=tileY(maxLat,zoom);y1=tileY(minLat,zoom);
        const startX=Math.floor(x0),endX=Math.max(startX,Math.ceil(x1)-1),startY=Math.floor(y0),endY=Math.max(startY,Math.ceil(y1)-1),tileSize=256,n=Math.pow(2,zoom);
        const mosaic=document.createElement("canvas");mosaic.width=(endX-startX+1)*tileSize;mosaic.height=(endY-startY+1)*tileSize;
        const mc=mosaic.getContext("2d");if(!mc)return null;
        let loaded=0;const tasks:Array<Promise<void>>=[];
        for(let x=startX;x<=endX;x++)for(let y=startY;y<=endY;y++)tasks.push(this.loadTile(url,zoom,((x%n)+n)%n,Math.max(0,Math.min(n-1,y))).then(image=>{if(image){mc.drawImage(image,(x-startX)*tileSize,(y-startY)*tileSize,tileSize,tileSize);loaded++;}}));
        await Promise.all(tasks);if(!loaded)return null;
        const sx=(x0-startX)*tileSize,sw=Math.max(1,(x1-x0)*tileSize),sh=Math.max(1,(y1-y0)*tileSize);
        const result=document.createElement("canvas");result.width=Math.max(1,Math.min(2048,Math.round(sw)));result.height=Math.max(1,Math.min(2048,Math.round(sh)));
        const rc=result.getContext("2d");if(!rc)return null;
        for(let row=0;row<result.height;row++){
            const ratio=result.height===1?0:row/(result.height-1),latitude=maxLat-(maxLat-minLat)*ratio,sourceY=(tileY(latitude,zoom)-startY)*tileSize;
            rc.drawImage(mosaic,sx,sourceY,sw,1,0,row,result.width,1);
        }
        return result;
    }

    private loadTile(template:string,z:number,x:number,y:number):Promise<HTMLImageElement|null>{
        const url=template.replace(/\{s\}/g,"a").replace(/\{z\}/g,String(z)).replace(/\{x\}/g,String(x)).replace(/\{y\}/g,String(y));
        return new Promise(resolve=>{const image=new Image();image.crossOrigin="anonymous";image.onload=()=>resolve(image);image.onerror=()=>resolve(null);image.src=url;});
    }

    private addRotationButton(container:d3.Selection<HTMLDivElement,unknown,null,undefined>,text:string,label:string,delta:number,reset=false):void{
        container.append("button").attr("type","button").attr("aria-label",label).attr("title",label).text(text).on("click",(event:MouseEvent)=>{
            event.preventDefault();event.stopPropagation();
            const next=this.normalizeAngle(reset?0:(this.interactiveRotation??0)+delta);
            this.interactiveRotation=next;
            this.host.persistProperties({merge:[{objectName:"perspectiveInset",selector:null,properties:{rotation:next}}]});
            if(this.currentInsetGeo)this.drawPerspectiveInset(this.currentInsetGeo);
        });
    }

    private normalizeAngle(value:number):number{const finite=Number.isFinite(value)?value:0;return Math.round(((finite%360)+360)%360);}

    private contourLines(geo:GeoJSON.GeoJsonObject):Array<{coordinates:Position[];elevation:number;color:string}>{
        const output:Array<{coordinates:Position[];elevation:number;color:string}>=[],fallback=this.formattingSettings.lineStyle.color.value.value;
        const visit=(geometry:GeoJSON.Geometry|null,feature:GeoJSON.Feature):void=>{
            if(!geometry)return;
            const property=this.formattingSettings.elevationBands.propertyName.value.trim()||"elevation_m";
            const raw=feature.properties?.[property]??feature.properties?.elevation_m??feature.properties?.elevation;
            const elevation=Number(raw),z=Number.isFinite(elevation)?Math.max(0,elevation):0,color=this.featureColor(feature,fallback);
            if(geometry.type==="LineString")output.push({coordinates:geometry.coordinates as Position[],elevation:z,color});
            else if(geometry.type==="MultiLineString")geometry.coordinates.forEach(line=>output.push({coordinates:line as Position[],elevation:z,color}));
            else if(geometry.type==="Polygon")geometry.coordinates.forEach(ring=>output.push({coordinates:ring as Position[],elevation:z,color}));
            else if(geometry.type==="MultiPolygon")geometry.coordinates.forEach(polygon=>polygon.forEach(ring=>output.push({coordinates:ring as Position[],elevation:z,color})));
            else if(geometry.type==="GeometryCollection")geometry.geometries.forEach(child=>visit(child,feature));
        };
        const add=(feature:GeoJSON.Feature):void=>visit(feature.geometry,feature);
        if(geo.type==="FeatureCollection")(geo as GeoJSON.FeatureCollection).features.forEach(add);else if(geo.type==="Feature")add(geo as GeoJSON.Feature);else visit(geo as GeoJSON.Geometry,{type:"Feature",properties:{},geometry:geo as GeoJSON.Geometry});
        return output.filter(line=>line.coordinates.length>1);
    }

    private extractModelPoints(table?:DataViewTable):ModelPoint[]{
        if(!table)return[];const i=this.roleIndices(table);if(i.latitude<0||i.longitude<0)return[];
        return table.rows.map((row,rowIndex)=>{const lat=Number(row[i.latitude]),lon=Number(row[i.longitude]);if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat< -90||lat>90||lon< -180||lon>180)return null;
            const elevation=i.elevation>=0?Number(row[i.elevation]):undefined,rawOrder=i.pointOrder>=0?Number(row[i.pointOrder]):rowIndex;
            return{lat,lon,elevation:Number.isFinite(elevation)?elevation:undefined,order:Number.isFinite(rawOrder)?rawOrder:rowIndex,lineId:i.lineId>=0?String(row[i.lineId]??"Line 1"):"Line 1",label:i.label>=0?String(row[i.label]??""):undefined} as ModelPoint;
        }).filter((d):d is ModelPoint=>d!==null);
    }
    private extractTopologyText(table?:DataViewTable):string{if(!table)return"";const idx=this.roleIndices(table).topologyText;if(idx<0)return"";const value=table.rows.find(row=>typeof row[idx]==="string"&&String(row[idx]).trim())?.[idx];return typeof value==="string"?value.trim():"";}
    private roleIndices(table:DataViewTable):Record<string,number>{const roles=["latitude","longitude","elevation","lineId","pointOrder","label","topologyText"];return Object.fromEntries(roles.map(role=>[role,table.columns.findIndex(column=>Boolean(column.roles?.[role]))]));}
    private pointsToGeoJson(points:ModelPoint[]):GeoJSON.FeatureCollection{
        const lines=Array.from(d3.group(points,d=>d.lineId),([lineId,values])=>({type:"Feature" as const,properties:{lineId,elevation:values.find(value=>value.elevation!==undefined)?.elevation},geometry:{type:"LineString" as const,coordinates:values.sort((a,b)=>a.order-b.order).map(d=>[d.lon,d.lat] as Position)}}));
        return{type:"FeatureCollection",features:lines};
    }
    private parseTopology(text:string,objectName:string):GeoJSON.GeoJsonObject{let parsed:unknown;try{parsed=JSON.parse(text);}catch{throw new Error("The supplied topology is not valid JSON.");}return this.normalizeTopology(parsed,objectName);}
    private normalizeTopology(parsed:unknown,objectName:string):GeoJSON.GeoJsonObject{
        if(!parsed||typeof parsed!=="object"||!("type" in parsed))throw new Error("Expected a GeoJSON or TopoJSON object.");
        const typed=parsed as{type:string;objects?:Record<string,object>};if(typed.type==="Topology"){const objects=typed.objects||{},key=objectName.trim()||Object.keys(objects)[0];if(!key||!objects[key])throw new Error(`TopoJSON object '${key||"(none)"}' was not found.`);return topojsonFeature(parsed as never,objects[key] as never) as unknown as GeoJSON.GeoJsonObject;}return parsed as GeoJSON.GeoJsonObject;
    }
    private async fetchTopology(url:string,objectName:string):Promise<GeoJSON.GeoJsonObject>{if(url===this.cachedUrl&&this.cachedRemote)return this.cachedRemote;const response=await fetch(url,{credentials:"omit",mode:"cors"});if(!response.ok)throw new Error(`Topology request returned HTTP ${response.status}.`);const geo=this.normalizeTopology(await response.json(),objectName);this.cachedUrl=url;this.cachedRemote=geo;return geo;}
    private pointTitle(point:ModelPoint):string{const bits=[point.label||point.lineId,`${point.lat.toFixed(6)}, ${point.lon.toFixed(6)}`];if(point.elevation!==undefined)bits.push(`Elevation: ${point.elevation}`);return bits.join("\n");}
    private showStatus(message:string,error:boolean,subtle=false):void{this.status.text(message).classed("hidden",false).classed("error",error).classed("subtle",subtle);}
    private percent(value:number):number{return Math.max(0,Math.min(100,value))/100;}
    private message(error:unknown):string{return error instanceof Error?error.message:String(error);}
}
